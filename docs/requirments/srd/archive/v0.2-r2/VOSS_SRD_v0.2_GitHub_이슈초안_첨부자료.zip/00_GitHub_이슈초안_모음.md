# VOSS SRD v0.2 — GitHub 이슈 초안 모음

**상태:** 미게시 초안 · 기존 #6 본문 보강1개·신규6개  
**일정:** 10/06 18:30 공동회신,10/07 첫실험/실측,10/10 G0통과 목표(KST)

개별본문과실제첨부파일은 `repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/`에있다. 아래 문서 링크는 이 묶음에 포함한 실제 첨부 파일로 연결한다. 게시용링크는승인후실제commit으로고정한다.


---

# SRD·시스템 아키텍처 그림을 docs/requirements 에 반영

**작업:** update · **담당:** @ok778ts123

담당: 박병후 @ok778ts123 (10/05 PL이 배정)

## 할 일
- [ ] Claude Docs 의 SRD 를 Markdown 으로 내보내 `docs/requirements/VOSS_SRD.md` 로 올린다 (원본 그대로, 사본은 직접 고치지 않는다)
- [ ] 시스템 아키텍처 그림을 `docs/requirements/architecture/` 에 올린다: `VOSS_logic.svg`(논리 구성도), `VOSS_deploy.svg`(배포 구성도)
- [ ] `docs/requirements/README.md` 표의 판·올린 날 칸을 채운다

## 참고
- 레포가 **공개**다. API 키·개인 연락처가 없는지 확인하고 올린다
- SRD 의 노드·토픽 표(9장)가 `docs/interfaces/topics.md` 와 다르면 PR 본문에 적는다. 계약은 docs/interfaces 가 기준이다 (CLAUDE.md 절대 규칙 2)
- 개발 요약 `docs/architecture.md` 는 PL 담당. 그림이 바뀌어 요약과 달라지면 PR 에 적어 PL 에게 알린다


---

## SRD v0.2 r2 회신 취합·상호확인 관리

**취합/상태 관리:** 박병후 @ok778ts123 · **범위/계약 검토:** 남현지 @yujh5537 및 영향 담당자  
**공동 확인:** 남현지 @yujh5537, 김학민 @rokeyhak, 정의석 @EuiseokJeongNZ, 박병후 @ok778ts123

4인 회신을 대조해 공통 16개 내용을 SRD r2에 반영했고, 충돌·전제 차이·계약 공백·실측/승인 근거 부족 34개를 6개 조합으로 정리했습니다. 기존70개 SYS/VT·18개 IC·26개 TBD는 유지했습니다. 이 이슈를 상위 관리로 사용하고 각 조합의 공동 답변은 아래 6개 이슈에 모읍니다.

### 일정·우선순위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

### 상호확인 이슈 6개

아래는 등록 전 초안 링크입니다. 실제 등록 후 병후가 이슈 번호/URL과 진행 상태를 기입합니다.

| 조합/공동 담당 | 작성할 초안 | 연결 MC 수 | 공동 회신 상태 |
| --- | --- | --- | --- |
| 남현지–박병후 / @yujh5537·@ok778ts123 | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md) | 14 | 등록/회신 대기 |
| 남현지–김학민 / @yujh5537·@rokeyhak | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md) | 15 | 등록/회신 대기 |
| 남현지–정의석 / @yujh5537·@EuiseokJeongNZ | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md) | 14 | 등록/회신 대기 |
| 김학민–박병후 / @rokeyhak·@ok778ts123 | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md) | 12 | 등록/회신 대기 |
| 박병후–정의석 / @ok778ts123·@EuiseokJeongNZ | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md) | 7 | 등록/회신 대기 |
| 김학민–정의석 / @rokeyhak·@EuiseokJeongNZ | [이슈 본문 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md) | 4 | 등록/회신 대기 |

### 필요한 자료 전체

- [배포 안내·팀원 전달문](repository_files/docs/requirements/srd-v0.2-r2/markdown/00_취합결과_배포안내.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/00_취합결과_배포안내.docx)
- [SRD r2 취합 반영본](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/02_합치_충돌_미정_통합대장.docx)
- [검증 카드/70개 SYS·VT 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [추가로 받을 자료·결정·실행 순서](repository_files/docs/requirements/srd-v0.2-r2/markdown/10_추가자료_결정_실행순서.md)
- [시스템 논리 구조도](repository_files/docs/requirements/srd-v0.2-r2/assets/VOSS_회신취합_논리구조.png)
- [전체 배포 ZIP: 문서11개×Word/Markdown, 4인 원본 회신, 이전SRD, 그림·등록/검증 정보](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

각 조합 문서와 원본은 ZIP 및 자료 폴더에 있습니다. 실제 게시할 때 각 문서 링크는 같은 업로드 commit SHA에 고정해 브랜치 삭제/문서 교체 후에도 기준 자료를 확인할 수 있게 합니다.

### 병후가 갱신할 진행 체크

- [ ] 자료 게시와 6개 상호확인 이슈 등록 후 실제 번호·링크를 채웠다.
- [ ] 오늘18:30까지 작성된 공동 답변과 미정 이유·담당·예정일을 모았다.
- [ ] A 최소 연결 계약을 우선 확인하고, 같은 MC-ID에 연결된 모든 영향 담당자의 결론을 대조했다.
- [ ] 합의된 사항을 SRD 본문·IC·VT·TBD·변경 대장에 반영했다. 미합의는 담당/기한/후속 이슈로 계속 추적한다.
- [ ] 새 IDL/필드/설정/ADR 변경을 docs/interfaces와 코드에 동기화할 PR·rebuild/배포 계획을 연결했다.
- [ ] 10/07까지 첫 실기 실험·실측의 조건·횟수·원본 로그·확인자를 남겼다.
- [ ] 10/10까지 실제1박스 G0의 인식·픽업·적재·DBcommit/조회·복귀 증거와 수락 확인을 남겼다.
- [ ] B 후속 필수 및 선택 C 상태·검증 계획과 PL 기준선 검토를 연결했다.

### MC별 전체 계약 상태

조합별 회신 완료와 전체 계약 확정은 각각 기록합니다. 다자 계약은 동일 MC-ID의 모든 영향 담당자가 같은 규약에 수용 확인을 남기고 PL 검토를 마쳐야 닫습니다. 한 조합의 체크나 18:30 마감만으로 계약/실측/수락 상태를 확정하지 않습니다.

| MC-ID | 확인 사항 | 단계 | 연결 조합 | 전체 상태 |
| --- | --- | --- | --- | --- |
| MC-001 | 픽셀→베이스 위치의 제공 책임·출력 단위 | A | 남현지–박병후 | 미확정/상호확인 전 |
| MC-002 | 고정 관측 자세 호모그래피와 이동 카메라 추종 | A | 남현지–박병후, 남현지–김학민, 김학민–박병후 | 미확정/상호확인 전 |
| MC-003 | track/box/session/task/attempt 유일성과 재투입 | A/B | 남현지–정의석, 남현지–박병후, 박병후–정의석 | 미확정/상호확인 전 |
| MC-004 | 촬영·pose·제어 시각과 시계 이력 | A/B | 남현지–박병후, 김학민–박병후, 남현지–김학민 | 미확정/상호확인 전 |
| MC-005 | 재시도 담당과 액션/attempt 경계 | B | 남현지–박병후 | 미확정/상호확인 전 |
| MC-006 | 픽업 phase·성공 인계·reason enum | A/B | 남현지–박병후, 김학민–박병후 | 미확정/상호확인 전 |
| MC-007 | 2차 OCR 실현가능성과 수렴 프레임 | B | 남현지–박병후 | 미확정/상호확인 전 |
| MC-008 | 10/10 게이트와 개루프 검토 조건 | A/B | 남현지–박병후, 김학민–박병후 | 미확정/상호확인 전 |
| MC-009 | 단일 설정 snapshot·스키마·단위·유효값 | A | 남현지–김학민, 남현지–박병후, 김학민–박병후 | 미확정/상호확인 전 |
| MC-010 | 플랜지/TCP·orientation·좌표 원점 | A | 남현지–김학민, 김학민–박병후 | 미확정/상호확인 전 |
| MC-011 | speedl/servol/move_line 실제 API·큐·주기 | A/B | 김학민–박병후 | 미확정/상호확인 전 |
| MC-012 | RG2 파지 성공 피드백과 판정 방법 | A | 김학민–박병후 | 미확정/상호확인 전 |
| MC-013 | 닫힘 중 추종과 비차단 실행·busy 의미 | A | 김학민–박병후 | 미확정/상호확인 전 |
| MC-014 | cancel·watchdog·실제 정지 확인 | A/B | 남현지–박병후, 김학민–박병후, 남현지–김학민 | 미확정/상호확인 전 |
| MC-015 | 정지 후 보유 박스와 재개 | B | 남현지–김학민, 남현지–박병후 | 미확정/상호확인 전 |
| MC-016 | 적재 완료·결과 발행·복귀·DB 순서 | A/B | 남현지–김학민, 남현지–정의석, 박병후–정의석, 김학민–박병후 | 미확정/상호확인 전 |
| MC-017 | 재확인 자세·정지 OCR·재픽업 | B | 남현지–김학민 | 미확정/상호확인 전 |
| MC-018 | 구역 slot·hold 격자·용량 초과 | A/B | 남현지–김학민 | 미확정/상호확인 전 |
| MC-019 | 준비 판단 주담당·상태 원천·기동 | A/B | 남현지–김학민, 남현지–박병후, 김학민–정의석, 남현지–정의석 | 미확정/상호확인 전 |
| MC-020 | SortResult→DB 필드·enum·누락 데이터 | A/B | 남현지–정의석 | 미확정/상호확인 전 |
| MC-021 | 남은 수에서 FAILED 포함·재투입 집계 | B | 남현지–정의석, 박병후–정의석 | 미확정/상호확인 전 |
| MC-022 | Stats 제공자·API와 메모리 백업 | B | 남현지–정의석 | 미확정/상호확인 전 |
| MC-023 | 전체 분류·이력 질의·HOLD·명령 인자 | B | 남현지–정의석 | 미확정/상호확인 전 |
| MC-024 | 질문 ID·답변 유효성·30초·TTS 실패 | B | 남현지–정의석, 박병후–정의석 | 미확정/상호확인 전 |
| MC-025 | TTS 우선순위·중복 억제의 소유자 | B | 남현지–정의석 | 미확정/상호확인 전 |
| MC-026 | MQTT JSON·ack·중복·QoS·timestamp | B | 남현지–정의석, 김학민–정의석 | 미확정/상호확인 전 |
| MC-027 | DB 장애·다음 박스 허용·durable 보존 | A/B | 남현지–정의석, 박병후–정의석 | 미확정/상호확인 전 |
| MC-028 | 공용 PC 사양·GPU 동거·음성/비전 선택 | A/B | 남현지–정의석, 김학민–정의석 | 미확정/상호확인 전 |
| MC-029 | 호스트/컨테이너·DDS NIC·CT005 할당 | A/B | 김학민–정의석, 남현지–김학민, 남현지–정의석 | 미확정/상호확인 전 |
| MC-030 | 정상 사이클의 감지/적재 경계·재시도 분류 | B | 남현지–박병후, 박병후–정의석, 남현지–김학민 | 미확정/상호확인 전 |
| MC-031 | 시험 분모·판정·카드와 성능 측정 범위 | A/B | 남현지–박병후, 박병후–정의석, 김학민–박병후 | 미확정/상호확인 전 |
| MC-032 | 카메라 실행 설정·노출·작업대 실측 | A | 남현지–김학민 | 미확정/상호확인 전 |
| MC-033 | 선택 매핑/교시의 채택·원자 갱신 | C | 남현지–정의석, 남현지–김학민 | 미확정/상호확인 전 |
| MC-034 | 참조 BRD 판·브랜치·승인 증거 | A/B | 남현지–김학민 | 미확정/상호확인 전 |

### 주요 의존·기존 이슈

- 인터페이스 전체 관리: [#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10)
- 실측·gateway/그리퍼/정지적재: [#11](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/11) · [#34](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/34) · [#39](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/39) · [#40](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/40) · [#41](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/41) · [#43](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/43) · [#44](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/44)
- 비전/서보/OCR·FSM/DB: [#25](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/25) · [#28](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/28) · [#29](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/29) · [#30](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/30) · [#36](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/36) · [#37](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/37) · [#21](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/21)
- 기존 개루프 전환 게이트: [#13](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/13) · [#35](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/35) — MC-008에서 담당 방향과 기존 문구를 맞춘다. 이번 초안으로 자동 변경하지 않는다.
- LabelCrop/ReadLabel/ZoneMap 변경 [PR #47](https://github.com/yujh5537/rokey_cobot2_VOSS/pull/47), 호모그래피 [PR #48](https://github.com/yujh5537/rokey_cobot2_VOSS/pull/48), 검출 방식 결정 [PR #49](https://github.com/yujh5537/rokey_cobot2_VOSS/pull/49)는 이슈 초안 작성 시점 열린 PR로 확인했다. 승인 보고·코드 반영·실기 검증 상태를 따로 추적한다.

### 변경·회신 규약

공동 답변은 각 조합 이슈의 댓글로 받고, MC-ID를 유지합니다. 필수 변경만 기존 ID·변경 전후·필수 근거·영향·임시ID/대응표를 남겨 제안하고 관련 담당자 확인·PL 검토 뒤 반영합니다. 목표/설정/실측·모의/실기를 구분하며 정상 자동과 예외, 작업자 대기 시간은 별도로 기록합니다.


---

# [SRD v0.2 상호확인] 남현지–박병후 — 계약·미정 14건 공동 회신

**작업:** create · **담당:** @yujh5537, @ok778ts123

## 요청

**공동 확인:** 남현지 @yujh5537 · 박병후 @ok778ts123  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 14개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/03_남현지_박병후_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/03_남현지_박병후_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-001 / A — 픽셀→베이스 위치의 제공 책임·출력 단위** (명시적 충돌)
- [ ] **MC-002 / A — 고정 관측 자세 호모그래피와 이동 카메라 추종** (전제 충돌)
- [ ] **MC-003 / A/B — track/box/session/task/attempt 유일성과 재투입** (계약 공백·충돌 가능)
- [ ] **MC-004 / A/B — 촬영·pose·제어 시각과 시계 이력** (명시적 충돌·계약 공백)
- [ ] **MC-005 / B — 재시도 담당과 액션/attempt 경계** (명시적 충돌)
- [ ] **MC-006 / A/B — 픽업 phase·성공 인계·reason enum** (명시적 충돌·상세 미정)
- [ ] **MC-007 / B — 2차 OCR 실현가능성과 수렴 프레임** (전제 차이·요구사항 변경 제안)
- [ ] **MC-008 / A/B — 10/10 게이트와 개루프 검토 조건** (회신↔기존 문서 충돌)
- [ ] **MC-009 / A — 단일 설정 snapshot·스키마·단위·유효값** (대체로 합치·상세 공백)
- [ ] **MC-014 / A/B — cancel·watchdog·실제 정지 확인** (명시적 충돌·안전 계약 공백)
- [ ] **MC-015 / B — 정지 후 보유 박스와 재개** (명시적 충돌)
- [ ] **MC-019 / A/B — 준비 판단 주담당·상태 원천·기동** (할당 변경 제안·전달 공백)
- [ ] **MC-030 / B — 정상 사이클의 감지/적재 경계·재시도 분류** (명시적 충돌·세부 공백)
- [ ] **MC-031 / A/B — 시험 분모·판정·카드와 성능 측정 범위** (목표 합치·검증 상세 미정)

## 항목별 확인할 내용

### MC-001 — 픽셀→베이스 위치의 제공 책임·출력 단위

- **차이/현재 근거:** 남현지: BoxTrack 픽셀만 발행, servo/manager가 공용 함수로 변환. 출력 mm. 박병후: 현지의 변환 단계에서 base position·frame·valid를 공급받아 사용. ROS 입력 m.
- **공동 결정할 질문:** 변환 담당 노드와 공급 경로를 하나로 정할 것. 기존 픽셀 필드 유지 여부, base 위치 별도 출력 또는 명시적 추가 필드, mm→m 경계를 결정할 것.
- **남길 답변/증거:** 생산자/소비자·최종 메시지 또는 함수 API·상단 중심 기준·단위 변환·캘리브레이션 버전·실제 수신 예시.
- **연결 ID:** SYS-FR-007, IC-VISION-02, TBD-002·003; NEW-B-01
- **작성·확인 책임:** 남현지 주작성, 박병후 수용 확인

### MC-002 — 고정 관측 자세 호모그래피와 이동 카메라 추종

- **차이/현재 근거:** 남현지: 현재 호모그래피는 observe_pose에서만 유효. 카메라 이동 시 정식 핸드아이로 보완 예정. 박병후: 손목 카메라가 움직이는 동안 촬영 시점 pose로 계속 base 위치를 산출하는 폐루프.
- **공동 결정할 질문:** 고정 자세 캘리브레이션만으로 이동 추종이 되는 것으로 가정하지 말 것. 핸드아이/촬영 시점 pose 이력/평면 교점 방식과 담당·완료 조건을 결정할 것.
- **남길 답변/증거:** observe_pose·카메라 내부/외부 파라미터·툴 기준·이동 중 변환 식/담당·정적/동적 검증 로그. ≤5mm는 승인 전 제안.
- **연결 ID:** SYS-FR-007·008, SYS-CT-002, TBD-002·014·020
- **작성·확인 책임:** 남현지 변환 설계, 김학민 기준 자세/실측, 박병후 소비 검증
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-003 — track/box/session/task/attempt 유일성과 재투입

- **차이/현재 근거:** 남현지: 투입 회차별 box_id, 재시도는 같은 box_id의 attempt 1~3, 재투입은 새 box_id. 접두 MMDDTHHMM-순번. 정의석: attempt_id 또는 처리 시도별 box_id 유일키 제안. 박병후: task/session/attempt와 물리 박스 대응 필요.
- **공동 결정할 질문:** 처리 시도라는 말이 투입 회차인지 파지 재시도인지 통일할 것. 같은 분 재시작·노드 재기동·해가 바뀌어도 DB 키 충돌이 없는지, track 만료 후 같은 박스와 재투입을 구분하는지 확인할 것.
- **남길 답변/증거:** ID 대응표·유일키·생성/만료 주체·재시작 규약·물리 박스 시험대장. retry/reinsert/중복 수신 각 예시와 DB 행 수.
- **연결 ID:** SYS-FR-004·014, SYS-DT-001, TBD-003·007·008·012·022
- **작성·확인 책임:** 남현지 업무 ID, 정의석 DB키, 박병후 시험 ID 취합
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-004 — 촬영·pose·제어 시각과 시계 이력

- **차이/현재 근거:** 남현지: camera header.stamp를 호스트 촬영 시각으로 보존. 김학민: pose stamp는 조회 응답 수신 시각. 박병후: pose stamp는 실제 측정 시각, 촬영 시점의 pose/TF 이력 사용. 카메라 하드웨어 시계 매핑 확인 요구.
- **공동 결정할 질문:** 응답 수신 시각을 실제 장비 측정 시각으로 표기할 수 있는지 확인할 것. 불가하면 응답 시각·측정 불확실성·보간/예측 한계를 명시. 카메라 stamp domain, ROS/system/monotonic, 다중 PC 동기를 정할 것.
- **남길 답변/증거:** 시각 필드 정의표·시계 변환·pose 이력 보존/보간 범위·age/stale/future 기준·capture→consume 로그.
- **연결 ID:** SYS-PF-007, IC-VISION-01·02, IC-ROBOT-02, TBD-003·014·020·026
- **작성·확인 책임:** 김학민 pose 원천, 남현지 camera/변환, 박병후 제어 age
- **같은 계약의 추가 확인 조합:** 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-005 — 재시도 담당과 액션/attempt 경계

- **차이/현재 근거:** 남현지: manager가 실패 result를 받아 같은 box_id로 새 attempt/goal, 최대 2회 추가. 박병후: servo가 국소 재시도, manager는 최종 실패를 확정.
- **공동 결정할 질문:** 최대3회 카운터의 유일 소유자와 재시도 위치를 정할 것. 양쪽에서 재시도해 총횟수가 늘지 않도록 goal UUID·attempt·종료 result 관계를 확인.
- **남길 답변/증거:** 한 번 실패→재시도 성공/3회 실패/시야상실/안전오류의 호출 시퀀스·카운터·최종 result 수.
- **연결 ID:** SYS-FR-011, IC-PICK-01, TBD-019; NEW-B-04
- **작성·확인 책임:** 박병후 픽업안 작성, 남현지 FSM 연결

### MC-006 — 픽업 phase·성공 인계·reason enum

- **차이/현재 근거:** 남현지: approach/track/descend/grasp, 소문자 ok/lost/grasp_fail/canceled/robot_error. 박병후: prepare/track/descend/grasp/lift/verify, 대문자 OK/GRASP_FAILED/STALE_INPUT/DEVICE_ERROR 등 예시. 안전 높이까지 인계.
- **공동 결정할 질문:** phase와 reason의 최종 허용값·대소문자·ROS action status를 일치시킬 것. grasped=true의 물체 확보 및 lift 완료 경계와 인계 높이/자세를 명시할 것.
- **남길 답변/증거:** goal/feedback/result 정의·상태/사유 매핑표·인계 조건·timeout/BUSY 정책. err_u/v는 px 유지, m 오차는 별도 필드 후보.
- **연결 ID:** SYS-FR-009·010, SYS-IF-002, IC-PICK-01, TBD-019; NEW-B-04
- **작성·확인 책임:** 박병후 액션 의미, 남현지 소비, 김학민 모션 완료 확인
- **같은 계약의 추가 확인 조합:** 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-007 — 2차 OCR 실현가능성과 수렴 프레임

- **차이/현재 근거:** 남현지: tracker가 PICKING 상태·화면 목표점·선명도로 3~5장 선택, 서보 추가 신호 불필요. 약0.3초 시야 유지 추정. 박병후: 손목 시야/가림/거리상 불가능할 수 있어 B에서 실험 후 판단, 필요 시 수렴 신호 협의.
- **공동 결정할 질문:** PICKING만으로 내려가기/가림/목표 수렴을 구분할 수 있는지 실제 프레임으로 확인할 것. 가능/불가 조건과 신호·종료 시점을 정하고, 불가하면 대안 및 SYS/VT 변경 승인을 별도로 기록.
- **남길 답변/증거:** 실기 프레임·box/stage/stamp 대응·선택 기준·OCR 부하 영향·가능성 판정 및 변경 카드. 현 B 필수 요구를 자동 삭제하지 않음.
- **연결 ID:** SYS-FR-023, VT-023, IC-VISION-03·04, TBD-003·004·019; NEW-B-06
- **작성·확인 책임:** 남현지 OCR/PL, 박병후 추종 실험

### MC-008 — 10/10 게이트와 개루프 검토 조건

- **차이/현재 근거:** 저장소 ADR-0002: B 개루프 베이스라인부터, 10/10 14/20 미달이면 B로 전환. 남현지: 같은 ADR을 기준으로 A/B 전환 가능 기재. 박병후: 폐루프 FF+P 우선. 실측 성능이 상당히 부족하다고 팀 판단할 때만 개루프 대안을 검토. 날짜/목표 미달로 자동 전환하지 않음.
- **공동 결정할 질문:** 현재 담당 방향과 팀 기준선을 동기화할 것. 70% 목표와 성능 점검은 유지하며 대안 검토 조건·결정자·증거·ADR 갱신을 확인.
- **남길 답변/증거:** 팀 검토 기록·ADR-0002 정정안·현재 채택 방식·전환 미결정/결정 여부. speedl 미지원과 폐루프 포기를 구분.
- **연결 ID:** TBD-021, SYS-FR-008, SYS-PF-001; NEW-B-05; ADR-0002
- **작성·확인 책임:** 박병후 방향 제시, 남현지 PL·김학민 실행 경로 확인
- **같은 계약의 추가 확인 조합:** 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-009 — 단일 설정 snapshot·스키마·단위·유효값

- **차이/현재 근거:** 남현지: 정적 값 launch→parameters, runtime writer=manager, belt direction_axis, 미정 null 제안. 김학민: 방향은 base 단위벡터, zones/limits 필요. 박병후: Kp/height/offset/age/watchdog/TCP/calibration/version/valid를 함께 검증.
- **공동 결정할 질문:** launch 전달 원칙을 수용하는지, 전체 schema와 소비자 목록·단위를 정할 것. 좌표 mm/deg와 제어 SI 변환, 부호 있는 벨트 단위벡터·속도, 0/null의 유효성을 필드별로 구분할 것.
- **남길 답변/증거:** 버전/해시 있는 초기 설정 예시·노드별 parameter 표·검증/READY 조건·누락 거부 사례. angular=0 같은 정상 0까지 일괄 금지하지 않음.
- **연결 ID:** SYS-FR-033, SYS-IF-007, IC-CONFIG-01, TBD-006·013·017·018·020
- **작성·확인 책임:** 남현지 schema/bringup, 김학민 실측/limits, 박병후 제어 값
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-014 — cancel·watchdog·실제 정지 확인

- **차이/현재 근거:** 남현지: cancel 후 servo가 0속도 발행 후 canceled 반환 제안. 김학민: stop 서비스·pose 변화 없음 확인, 감시시간 미정. 박병후: 단발 0속도 의존 금지, 실제 정지 확인 후 cancel 완료. pose만으로 actualstop 판단하지 않음. 불확실하면 STOP_UNCONFIRMED/PAUSED/새goal금지.
- **공동 결정할 질문:** 정지 요청 담당·우선순위·독립 watchdog·command expiry·실제 정지 확인 근거/연속 확인 조건을 정할 것. gateway 프로세스 종료 시 장비 동작도 시험하고 물체 보유 중 자동 개방 금지 여부를 결정.
- **남길 답변/증거:** 단계별 stop/cancel/노드 종료 시퀀스·/voss/robot/stop 최종 타입·정지 모드·timeout/최대 지연·거리·confirmed/unconfirmed 표시와 재개 조건.
- **연결 ID:** SYS-SF-001·002, IC-PICK-01·ROBOT-03, TBD-005·017·019·020; NEW-R-04
- **작성·확인 책임:** 김학민 실제 중단, 박병후 액션, 남현지 전체 PAUSED
- **같은 계약의 추가 확인 조합:** 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-015 — 정지 후 보유 박스와 재개

- **차이/현재 근거:** 남현지: 파지 후 정지면 확정 구역으로 이동 계속/재확인 이동, ASKING 질문 재발화·30초 재시작. 김학민: 정지 후 보유 박스는 사람이 확인·제거. 박병후: 실제 정지/보유 상태 확인 후 새goal, 자동 개방 금지 방향.
- **공동 결정할 질문:** 재개 때 물체를 유지한 채 이어갈지 수동 제거할지 단계별 하나의 정책을 정할 것. start와 resume 차이, 노드 재기동과 단순 일시정지를 구분하고 이미 기록된 박스 중복 동작을 막을 것.
- **남길 답변/증거:** 정지 단계×물체 보유×기록 여부의 resume 전이표·인적 확인 지점·질문 타이머 정책.
- **연결 ID:** SYS-FR-019, TBD-005·017·019
- **작성·확인 책임:** 남현지 FSM, 김학민 보유/재기동, 박병후 픽업 중단
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-019 — 준비 판단 주담당·상태 원천·기동

- **차이/현재 근거:** 김학민: FR-001 주담당은 manager 남현지로 변경, gateway는 READY/로봇 상태 제공. stop/observe/state 신설 제안. 박병후: 설정/유효 입력/gateway READY 필수. 정의석: HMI 로봇 상태 데이터 원천 없음. 남현지: 통합 상태는6개 후보.
- **공동 결정할 질문:** FR-001의 주담당 변경·각 파트 ready/error/heartbeat와 통합 판단·로봇 상태 필드를 확인할 것. 관측 자세 이동 요청(zone=observe 또는 별도)을 정하고 launch/툴 등록/설정 적용 순서를 정할 것.
- **남길 답변/증거:** ready matrix·발행 주체/타입/주기·미준비 차단·stale/UNKNOWN 표시·기동/복구 체크. 상태 신설과 FR 담당 변경은 승인 후 반영.
- **연결 ID:** SYS-FR-001·031, IC-STATE-01, TBD-011·018; NEW-R-01·05·06
- **작성·확인 책임:** 남현지 통합, 김학민 장비, 정의석 화면/저장, 박병후 servo
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-030 — 정상 사이클의 감지/적재 경계·재시도 분류

- **차이/현재 근거:** 남현지: detected→SortResult(placed, decided_by=ocr), 재시도 포함 여부 명시 없음. 박병후: t_detect→실제t_placed, result/return/commit 별도. retry도 예외로 제안. 정상/예외/작업자대기 분리는 공통.
- **공동 결정할 질문:** t_detect는 최초 유효 capture/검출 처리/수신 중 무엇인지, placed는 물리 완료의 어떤 이벤트인지 결정. retry 포함/제외와 최대값/분포 합격 기준·종료실패/skip 측정을 확정.
- **남길 답변/증거:** 이벤트명·생산자·공통ID·clock·정상/예외 분류표·측정 계산식·CSV예시. human wait 구간은 MC024와 동일 결정.
- **연결 ID:** SYS-PF-004, VT-048, TBD-025
- **작성·확인 책임:** 박병후 측정, 남현지 detect/result, 김학민 placed, 정의석 evidence
- **같은 계약의 추가 확인 조합:** 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-031 — 시험 분모·판정·카드와 성능 측정 범위

- **차이/현재 근거:** 공통: 70%(20사례≥14)/OCR90·95/intent19of20/30초/3초/30Hz/100ms, 최종10물리박스≥8 목표. 전원실기 미수행. 정의석: API 실패는 intent 분모 별도, HMI 시작=bridge수신(전체 상태발행지연을 포함하지 않음). 반복횟수 제안 다수. 박병후: 사례사후제외금지, capture→consume 및 실제적용 구분.
- **공동 결정할 질문:** 실패/timeout/API오류/skip/재투입 분모·재시험 기준을 사전 고정할 것. HMI 상태 변경→DOM 목표와 bridge수신→DOM 부분구간을 구분하고 공용/브라우저 시계동기 방법을 정할 것. max/p95/평균 허용·부하·횟수/수행일을 승인.
- **남길 답변/증거:** 전체 VT계획표·case정답세트/환경·하위판정·수행일/확인자·rawlogs. 1차OCR≤300ms/검출30Hz BRD목표, 20ms·100ms crop 내부예산, ≤5mm제안 분리.
- **연결 ID:** SYS-PF-001~009, SYS-MT-001, TBD-020·022·025
- **작성·확인 책임:** 박병후 검증 취합, 각 기능 담당·남현지 PL
- **같은 계약의 추가 확인 조합:** 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#25](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/25) · [#28](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/28) · [#29](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/29) · [#30](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/30) · [#34](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/34) · [#35](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/35) · [#36](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/36) · [#37](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/37) · [#13](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/13)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.


---

# [SRD v0.2 상호확인] 남현지–김학민 — 계약·미정 15건 공동 회신

**작업:** create · **담당:** @yujh5537, @rokeyhak

## 요청

**공동 확인:** 남현지 @yujh5537 · 김학민 @rokeyhak  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 15개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/04_남현지_김학민_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/04_남현지_김학민_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-002 / A — 고정 관측 자세 호모그래피와 이동 카메라 추종** (전제 충돌)
- [ ] **MC-004 / A/B — 촬영·pose·제어 시각과 시계 이력** (명시적 충돌·계약 공백)
- [ ] **MC-009 / A — 단일 설정 snapshot·스키마·단위·유효값** (대체로 합치·상세 공백)
- [ ] **MC-010 / A — 플랜지/TCP·orientation·좌표 원점** (명시적 충돌·미정)
- [ ] **MC-014 / A/B — cancel·watchdog·실제 정지 확인** (명시적 충돌·안전 계약 공백)
- [ ] **MC-015 / B — 정지 후 보유 박스와 재개** (명시적 충돌)
- [ ] **MC-016 / A/B — 적재 완료·결과 발행·복귀·DB 순서** (명시적 충돌·전달 경로 공백)
- [ ] **MC-017 / B — 재확인 자세·정지 OCR·재픽업** (기능 경로 누락)
- [ ] **MC-018 / A/B — 구역 slot·hold 격자·용량 초과** (대체로 합치·상세 공백)
- [ ] **MC-019 / A/B — 준비 판단 주담당·상태 원천·기동** (할당 변경 제안·전달 공백)
- [ ] **MC-029 / A/B — 호스트/컨테이너·DDS NIC·CT005 할당** (상세 미정·담당 변경 제안)
- [ ] **MC-030 / B — 정상 사이클의 감지/적재 경계·재시도 분류** (명시적 충돌·세부 공백)
- [ ] **MC-032 / A — 카메라 실행 설정·노출·작업대 실측** (설정 합치·설치/증거 공백)
- [ ] **MC-033 / C — 선택 매핑/교시의 채택·원자 갱신** (선택 채택 미합의)
- [ ] **MC-034 / A/B — 참조 BRD 판·브랜치·승인 증거** (문서 기준선 차이)

## 항목별 확인할 내용

### MC-002 — 고정 관측 자세 호모그래피와 이동 카메라 추종

- **차이/현재 근거:** 남현지: 현재 호모그래피는 observe_pose에서만 유효. 카메라 이동 시 정식 핸드아이로 보완 예정. 박병후: 손목 카메라가 움직이는 동안 촬영 시점 pose로 계속 base 위치를 산출하는 폐루프.
- **공동 결정할 질문:** 고정 자세 캘리브레이션만으로 이동 추종이 되는 것으로 가정하지 말 것. 핸드아이/촬영 시점 pose 이력/평면 교점 방식과 담당·완료 조건을 결정할 것.
- **남길 답변/증거:** observe_pose·카메라 내부/외부 파라미터·툴 기준·이동 중 변환 식/담당·정적/동적 검증 로그. ≤5mm는 승인 전 제안.
- **연결 ID:** SYS-FR-007·008, SYS-CT-002, TBD-002·014·020
- **작성·확인 책임:** 남현지 변환 설계, 김학민 기준 자세/실측, 박병후 소비 검증
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-004 — 촬영·pose·제어 시각과 시계 이력

- **차이/현재 근거:** 남현지: camera header.stamp를 호스트 촬영 시각으로 보존. 김학민: pose stamp는 조회 응답 수신 시각. 박병후: pose stamp는 실제 측정 시각, 촬영 시점의 pose/TF 이력 사용. 카메라 하드웨어 시계 매핑 확인 요구.
- **공동 결정할 질문:** 응답 수신 시각을 실제 장비 측정 시각으로 표기할 수 있는지 확인할 것. 불가하면 응답 시각·측정 불확실성·보간/예측 한계를 명시. 카메라 stamp domain, ROS/system/monotonic, 다중 PC 동기를 정할 것.
- **남길 답변/증거:** 시각 필드 정의표·시계 변환·pose 이력 보존/보간 범위·age/stale/future 기준·capture→consume 로그.
- **연결 ID:** SYS-PF-007, IC-VISION-01·02, IC-ROBOT-02, TBD-003·014·020·026
- **작성·확인 책임:** 김학민 pose 원천, 남현지 camera/변환, 박병후 제어 age
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-009 — 단일 설정 snapshot·스키마·단위·유효값

- **차이/현재 근거:** 남현지: 정적 값 launch→parameters, runtime writer=manager, belt direction_axis, 미정 null 제안. 김학민: 방향은 base 단위벡터, zones/limits 필요. 박병후: Kp/height/offset/age/watchdog/TCP/calibration/version/valid를 함께 검증.
- **공동 결정할 질문:** launch 전달 원칙을 수용하는지, 전체 schema와 소비자 목록·단위를 정할 것. 좌표 mm/deg와 제어 SI 변환, 부호 있는 벨트 단위벡터·속도, 0/null의 유효성을 필드별로 구분할 것.
- **남길 답변/증거:** 버전/해시 있는 초기 설정 예시·노드별 parameter 표·검증/READY 조건·누락 거부 사례. angular=0 같은 정상 0까지 일괄 금지하지 않음.
- **연결 ID:** SYS-FR-033, SYS-IF-007, IC-CONFIG-01, TBD-006·013·017·018·020
- **작성·확인 책임:** 남현지 schema/bringup, 김학민 실측/limits, 박병후 제어 값
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-010 — 플랜지/TCP·orientation·좌표 원점

- **차이/현재 근거:** 김학민: zones는 플랜지 기준(TCP 미적용), pose 기준점은 미정. 남현지: 캘리브레이션 TCP 터치. 박병후: 실제 TCP pose·파지 offset·상단 중심의 대응을 전제로 함.
- **공동 결정할 질문:** 장비 API가 반환하는 기준점과 설정/pose/캘리브레이션 기준점을 통일하거나 변환을 명시할 것. base_link가 실제 두산 베이스와 일치하는지, ZYZ↔quaternion과 각속도 의미도 확인.
- **남길 답변/증거:** TCP/tool 명칭·오프셋·frame 관계·단위·변환 예시·재기동 재등록 절차·측정 조건.
- **연결 ID:** SYS-FR-007·012, SYS-IF-003, IC-ROBOT-02·03, TBD-002·014·016
- **작성·확인 책임:** 김학민 장비 기준, 남현지 캘리브레이션, 박병후 파지 기준
- **같은 계약의 추가 확인 조합:** 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-014 — cancel·watchdog·실제 정지 확인

- **차이/현재 근거:** 남현지: cancel 후 servo가 0속도 발행 후 canceled 반환 제안. 김학민: stop 서비스·pose 변화 없음 확인, 감시시간 미정. 박병후: 단발 0속도 의존 금지, 실제 정지 확인 후 cancel 완료. pose만으로 actualstop 판단하지 않음. 불확실하면 STOP_UNCONFIRMED/PAUSED/새goal금지.
- **공동 결정할 질문:** 정지 요청 담당·우선순위·독립 watchdog·command expiry·실제 정지 확인 근거/연속 확인 조건을 정할 것. gateway 프로세스 종료 시 장비 동작도 시험하고 물체 보유 중 자동 개방 금지 여부를 결정.
- **남길 답변/증거:** 단계별 stop/cancel/노드 종료 시퀀스·/voss/robot/stop 최종 타입·정지 모드·timeout/최대 지연·거리·confirmed/unconfirmed 표시와 재개 조건.
- **연결 ID:** SYS-SF-001·002, IC-PICK-01·ROBOT-03, TBD-005·017·019·020; NEW-R-04
- **작성·확인 책임:** 김학민 실제 중단, 박병후 액션, 남현지 전체 PAUSED
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-015 — 정지 후 보유 박스와 재개

- **차이/현재 근거:** 남현지: 파지 후 정지면 확정 구역으로 이동 계속/재확인 이동, ASKING 질문 재발화·30초 재시작. 김학민: 정지 후 보유 박스는 사람이 확인·제거. 박병후: 실제 정지/보유 상태 확인 후 새goal, 자동 개방 금지 방향.
- **공동 결정할 질문:** 재개 때 물체를 유지한 채 이어갈지 수동 제거할지 단계별 하나의 정책을 정할 것. start와 resume 차이, 노드 재기동과 단순 일시정지를 구분하고 이미 기록된 박스 중복 동작을 막을 것.
- **남길 답변/증거:** 정지 단계×물체 보유×기록 여부의 resume 전이표·인적 확인 지점·질문 타이머 정책.
- **연결 ID:** SYS-FR-019, TBD-005·017·019
- **작성·확인 책임:** 남현지 FSM, 김학민 보유/재기동, 박병후 픽업 중단
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md))

### MC-016 — 적재 완료·결과 발행·복귀·DB 순서

- **차이/현재 근거:** 남현지: 최종 그리퍼 개방 성공 직후, 복귀 전 SortResult 발행, DB commit 기다리지 않음. 사이클 detected→result. 김학민: MoveToZone 내부에서 개방+observe 복귀까지 하고 응답. 박병후: 실제placed/observe_ready/db_committed를 분리, 정상 사이클detect→placed. 정의석: commit/조회가 A 완료 조건.
- **공동 결정할 질문:** 현재 서비스 응답만으로 복귀 전 개방/placed를 manager가 어떻게 아는지 결정할 것. 서비스 의미 변경/중간 이벤트/응답 시각 필드 등 대안을 비교. manager의 DB 비차단과 G0 검증의 commit 필수를 구분.
- **남길 답변/증거:** placed/result/observe_ready/db_committed/query 시퀀스·이벤트 생산자/타입/시각·실패 시 결과 규칙. 개방 ack만으로 올바른 물리 적재가 확인되는지도 명시.
- **연결 ID:** SYS-FR-012·013·014, SYS-PF-004, IC-ROBOT-03·RESULT-01·DB-01, TBD-007·012·016·025
- **작성·확인 책임:** 김학민 모션 이벤트, 남현지 result, 정의석 commit, 박병후 측정
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-017 — 재확인 자세·정지 OCR·재픽업

- **차이/현재 근거:** 남현지: recheck에 놓은 뒤 read_label 호출, 확정 후 다시 집어 목적 구역 이동. MoveToZone pick 모드 필요. 김학민: 현 MoveToZone은 놓기+observe 복귀만 제공, 재확인에서 집기 요청 없음.
- **공동 결정할 질문:** recheck에 놓은 후 카메라가 송장을 볼 자세/track 연결을 어떻게 유지하는지 정할 것. 정지 재판독 및 동일 박스 재픽업의 호출 경로·높이·실패 처리를 추가할 것.
- **남길 답변/증거:** recheck place→촬영 자세→read_label→응답/질문→repick→final place 시퀀스 및 타입·실제 영상.
- **연결 ID:** SYS-FR-025·027, IC-ROBOT-03·VISION-04, TBD-004·016
- **작성·확인 책임:** 김학민 정적 repick, 남현지 OCR/FSM

### MC-018 — 구역 slot·hold 격자·용량 초과

- **차이/현재 근거:** 김학민: A/B/C 2×2 pitch60mm, 중심 원점/행우선 slot, 카운터 manager. recheck1칸, hold 격자 없음. 남현지: 구역 좌표/설정 공급, hold 용량·가득 참 후속 처리 미제시.
- **공동 결정할 질문:** slot 소유/증가 시점·실패 시 재사용·reset·격자 원점·hold 크기를 확인할 것. 전체/우선 재투입 시 capacity 소진과 수동 비우기 정책을 정할 것.
- **남길 답변/증거:** 5구역 pose/grid 표·slot→좌표 예시·적재/실패/가득 참 시험·수동 비우기 확인 규약.
- **연결 ID:** SYS-FR-012, IC-CONFIG-01·ROBOT-03, TBD-005·016
- **작성·확인 책임:** 김학민 물리 grid, 남현지 카운터/가득 참 FSM

### MC-019 — 준비 판단 주담당·상태 원천·기동

- **차이/현재 근거:** 김학민: FR-001 주담당은 manager 남현지로 변경, gateway는 READY/로봇 상태 제공. stop/observe/state 신설 제안. 박병후: 설정/유효 입력/gateway READY 필수. 정의석: HMI 로봇 상태 데이터 원천 없음. 남현지: 통합 상태는6개 후보.
- **공동 결정할 질문:** FR-001의 주담당 변경·각 파트 ready/error/heartbeat와 통합 판단·로봇 상태 필드를 확인할 것. 관측 자세 이동 요청(zone=observe 또는 별도)을 정하고 launch/툴 등록/설정 적용 순서를 정할 것.
- **남길 답변/증거:** ready matrix·발행 주체/타입/주기·미준비 차단·stale/UNKNOWN 표시·기동/복구 체크. 상태 신설과 FR 담당 변경은 승인 후 반영.
- **연결 ID:** SYS-FR-001·031, IC-STATE-01, TBD-011·018; NEW-R-01·05·06
- **작성·확인 책임:** 남현지 통합, 김학민 장비, 정의석 화면/저장, 박병후 servo
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-029 — 호스트/컨테이너·DDS NIC·CT005 할당

- **차이/현재 근거:** 김학민: Mosquitto host1883, vision/DB owner 분리, DDS lo-only 수정 예정·유선 gateway 제거·host-network. 정의석: Web React+Spring Boot, DBPostgreSQL, broker host/container 모두 제안. 최종 위치/포트/볼륨 미정. 남현지 vision container.
- **공동 결정할 질문:** 실행 위치/이미지/포트/host-network/domain/NIC/읽기전용 설정/DBvolume를 정할 것. CT005 주담당 변경은 비전·DB 담당과 확인. DDS와 인터넷/MQTT 접근을 함께 검증.
- **남길 답변/증거:** 배포표·책임자·compose/launch 버전·포트/라우팅/DDS시험·API접속·기동/복구·volume. React/Spring/PostgreSQL은 현재 확정하지 않음.
- **연결 ID:** SYS-CT-005, VT-064, TBD-011·012·018·026; NEW-R-03
- **작성·확인 책임:** 김학민 network/host, 남현지 vision, 정의석 web/DB
- **같은 계약의 추가 확인 조합:** 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-030 — 정상 사이클의 감지/적재 경계·재시도 분류

- **차이/현재 근거:** 남현지: detected→SortResult(placed, decided_by=ocr), 재시도 포함 여부 명시 없음. 박병후: t_detect→실제t_placed, result/return/commit 별도. retry도 예외로 제안. 정상/예외/작업자대기 분리는 공통.
- **공동 결정할 질문:** t_detect는 최초 유효 capture/검출 처리/수신 중 무엇인지, placed는 물리 완료의 어떤 이벤트인지 결정. retry 포함/제외와 최대값/분포 합격 기준·종료실패/skip 측정을 확정.
- **남길 답변/증거:** 이벤트명·생산자·공통ID·clock·정상/예외 분류표·측정 계산식·CSV예시. human wait 구간은 MC024와 동일 결정.
- **연결 ID:** SYS-PF-004, VT-048, TBD-025
- **작성·확인 책임:** 박병후 측정, 남현지 detect/result, 김학민 placed, 정의석 evidence
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-032 — 카메라 실행 설정·노출·작업대 실측

- **차이/현재 근거:** 남현지: 목표/설정1920×1080 rgb8 30fps, 수동5~8ms고정 화이트밸런스, 상류왼쪽/진행오른쪽. 김학민: 실제브링업1280×720인 차이 지적, 노출/pose/벨트속도/투입위치/간섭 미측정.
- **공동 결정할 질문:** 실제 launch가1080p·rgb8·30fps인지 확인하고 단위/driver 노출 속성/카메라info를 기록. 해상도/observepose/벨트높이 바뀌면 캘리브레이션 갱신. 오른쪽을base방향으로 명시.
- **남길 답변/증거:** 카메라/노출/화이트밸런스 설정·실제FPS·벨트설정별3회/편차·투입/관측분리사진·5구역좌표·케이블/가이드/회수함. 미측정 좌표를0으로 확정하지 않음.
- **연결 ID:** SYS-FR-002·003, SYS-EN-001~003, TBD-001·002·013·016·017
- **작성·확인 책임:** 김학민 실장비·배치, 남현지 영상/캘리브레이션

### MC-033 — 선택 매핑/교시의 채택·원자 갱신

- **차이/현재 근거:** 남현지: 매핑변경10/11이후 채택 제안, 이미PICKING 목적구역 유지·원자swap/실패원복. 정의석/박병후: 후속검토, 현재선택미채택. 김학민: teach좌표 반환필드 없음/저장=manager원칙, TCP/플랜지차이.
- **공동 결정할 질문:** G0이후에만 채택 여부를 정할 것. 채택 시 동일box의 최종목적구역결정 시점·rule_version·confirm/rollback·teachpose반환/등록취소 경로를 확정.
- **남길 답변/증거:** 선택 채택/미채택 기록·영향·원자변경·TeachZone 응답·writer권한·별도시험. C미확정을A완료 차단조건으로 쓰지 않음.
- **연결 ID:** SYS-OP-001·002, IC-OPTION-01, TBD-023·024
- **작성·확인 책임:** 남현지 PL, 정의석 intent/HMI, 김학민 teach
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-034 — 참조 BRD 판·브랜치·승인 증거

- **차이/현재 근거:** 김학민: BRD v1.2(10/06) 참조. 남현지/박병후 및 기존SRD: v1.1. 남현지: LabelCrop/ReadLabel/ZoneMap code·aliases 팀승인 주장·branch386d632. 현재 제공된 BRD는 v1.1, 로컬main668703e에 새 타입/필드 없음. 다른회신은 직접확인없음, 승인기록/새브랜치 미첨부.
- **공동 결정할 질문:** 최종 적용BRD 판과 diff를 제공/확인할 것. 팀승인3건은 승인자/일시/최종schema/PR·commit으로 확인. 정의 변경은필드추가만으로wire호환이보장되지 않으므로동시rebuild/배포.
- **남길 답변/증거:** BRD v1.2 또는v1.1유지 결정·변경대비표·3건 승인증거/PR·타입diff·consumer목록/rebuild 계획. 이번SRD는owner보고 후보로만 수록.
- **연결 ID:** SRD §1.3/§9, SYS-IF-008, TBD-003·006·022
- **작성·확인 책임:** 남현지 문서/PL, 김학민 참조판 확인, 박병후 기준선 취합

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#25](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/25) · [#26](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/26) · [#29](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/29) · [#31](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/31) · [#39](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/39) · [#40](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/40) · [#41](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/41) · [#42](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/42) · [#44](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/44) · [#45](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/45)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.


---

# [SRD v0.2 상호확인] 남현지–정의석 — 계약·미정 14건 공동 회신

**작업:** create · **담당:** @yujh5537, @EuiseokJeongNZ

## 요청

**공동 확인:** 남현지 @yujh5537 · 정의석 @EuiseokJeongNZ  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 14개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/05_남현지_정의석_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/05_남현지_정의석_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-003 / A/B — track/box/session/task/attempt 유일성과 재투입** (계약 공백·충돌 가능)
- [ ] **MC-016 / A/B — 적재 완료·결과 발행·복귀·DB 순서** (명시적 충돌·전달 경로 공백)
- [ ] **MC-019 / A/B — 준비 판단 주담당·상태 원천·기동** (할당 변경 제안·전달 공백)
- [ ] **MC-020 / A/B — SortResult→DB 필드·enum·누락 데이터** (명시적 충돌·계약 공백)
- [ ] **MC-021 / B — 남은 수에서 FAILED 포함·재투입 집계** (명시적 충돌)
- [ ] **MC-022 / B — Stats 제공자·API와 메모리 백업** (명시적 차이·계약 공백)
- [ ] **MC-023 / B — 전체 분류·이력 질의·HOLD·명령 인자** (명시적 충돌·양식 공백)
- [ ] **MC-024 / B — 질문 ID·답변 유효성·30초·TTS 실패** (대체로 합치·계약 공백)
- [ ] **MC-025 / B — TTS 우선순위·중복 억제의 소유자** (명시적 충돌)
- [ ] **MC-026 / B — MQTT JSON·ack·중복·QoS·timestamp** (회신↔기존 계약 차이·미정)
- [ ] **MC-027 / A/B — DB 장애·다음 박스 허용·durable 보존** (정책 미합의)
- [ ] **MC-028 / A/B — 공용 PC 사양·GPU 동거·음성/비전 선택** (증거 수준 차이·자원 공백)
- [ ] **MC-029 / A/B — 호스트/컨테이너·DDS NIC·CT005 할당** (상세 미정·담당 변경 제안)
- [ ] **MC-033 / C — 선택 매핑/교시의 채택·원자 갱신** (선택 채택 미합의)

## 항목별 확인할 내용

### MC-003 — track/box/session/task/attempt 유일성과 재투입

- **차이/현재 근거:** 남현지: 투입 회차별 box_id, 재시도는 같은 box_id의 attempt 1~3, 재투입은 새 box_id. 접두 MMDDTHHMM-순번. 정의석: attempt_id 또는 처리 시도별 box_id 유일키 제안. 박병후: task/session/attempt와 물리 박스 대응 필요.
- **공동 결정할 질문:** 처리 시도라는 말이 투입 회차인지 파지 재시도인지 통일할 것. 같은 분 재시작·노드 재기동·해가 바뀌어도 DB 키 충돌이 없는지, track 만료 후 같은 박스와 재투입을 구분하는지 확인할 것.
- **남길 답변/증거:** ID 대응표·유일키·생성/만료 주체·재시작 규약·물리 박스 시험대장. retry/reinsert/중복 수신 각 예시와 DB 행 수.
- **연결 ID:** SYS-FR-004·014, SYS-DT-001, TBD-003·007·008·012·022
- **작성·확인 책임:** 남현지 업무 ID, 정의석 DB키, 박병후 시험 ID 취합
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-016 — 적재 완료·결과 발행·복귀·DB 순서

- **차이/현재 근거:** 남현지: 최종 그리퍼 개방 성공 직후, 복귀 전 SortResult 발행, DB commit 기다리지 않음. 사이클 detected→result. 김학민: MoveToZone 내부에서 개방+observe 복귀까지 하고 응답. 박병후: 실제placed/observe_ready/db_committed를 분리, 정상 사이클detect→placed. 정의석: commit/조회가 A 완료 조건.
- **공동 결정할 질문:** 현재 서비스 응답만으로 복귀 전 개방/placed를 manager가 어떻게 아는지 결정할 것. 서비스 의미 변경/중간 이벤트/응답 시각 필드 등 대안을 비교. manager의 DB 비차단과 G0 검증의 commit 필수를 구분.
- **남길 답변/증거:** placed/result/observe_ready/db_committed/query 시퀀스·이벤트 생산자/타입/시각·실패 시 결과 규칙. 개방 ack만으로 올바른 물리 적재가 확인되는지도 명시.
- **연결 ID:** SYS-FR-012·013·014, SYS-PF-004, IC-ROBOT-03·RESULT-01·DB-01, TBD-007·012·016·025
- **작성·확인 책임:** 김학민 모션 이벤트, 남현지 result, 정의석 commit, 박병후 측정
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-019 — 준비 판단 주담당·상태 원천·기동

- **차이/현재 근거:** 김학민: FR-001 주담당은 manager 남현지로 변경, gateway는 READY/로봇 상태 제공. stop/observe/state 신설 제안. 박병후: 설정/유효 입력/gateway READY 필수. 정의석: HMI 로봇 상태 데이터 원천 없음. 남현지: 통합 상태는6개 후보.
- **공동 결정할 질문:** FR-001의 주담당 변경·각 파트 ready/error/heartbeat와 통합 판단·로봇 상태 필드를 확인할 것. 관측 자세 이동 요청(zone=observe 또는 별도)을 정하고 launch/툴 등록/설정 적용 순서를 정할 것.
- **남길 답변/증거:** ready matrix·발행 주체/타입/주기·미준비 차단·stale/UNKNOWN 표시·기동/복구 체크. 상태 신설과 FR 담당 변경은 승인 후 반영.
- **연결 ID:** SYS-FR-001·031, IC-STATE-01, TBD-011·018; NEW-R-01·05·06
- **작성·확인 책임:** 남현지 통합, 김학민 장비, 정의석 화면/저장, 박병후 servo
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md))

### MC-020 — SortResult→DB 필드·enum·누락 데이터

- **차이/현재 근거:** 남현지: decided_by=ocr/recheck/operator, outcome=placed/held/failed/passed(추가 후보), raw_text/reason/attempts 추가. 정의석: DB decided_by=AUTO/OPERATOR/TIMEOUT, result=PLACED/HELD/FAILED, track_id/started_at/second_region/rule_version/retries 등.
- **공동 결정할 질문:** 대소문자·enum 및 의미 매핑을 정할 것. TIMEOUT은 판정 주체인지 reason인지, passed 저장/집계, attempts 총횟수↔retries 추가횟수(attempts-1) 경계를 확인. 현 메시지에 없는 DB 필드 전달 경로를 정할 것.
- **남길 답변/증거:** ROS→DB 컬럼 매핑·nullable/필수/실제 타입·OCR 원문/2위 후보·start/finish/rule_version 원천·4결과 실제 JSON/행 예시. 누락값을 추정으로 채우지 않음.
- **연결 ID:** SYS-IF-004, IC-RESULT-01·DB-01, TBD-007·012; NEW-V-01·02
- **작성·확인 책임:** 남현지 result 원천, 정의석 schema/변환

### MC-021 — 남은 수에서 FAILED 포함·재투입 집계

- **차이/현재 근거:** 남현지: remaining=planned−(placed+held+failed), passed 제외. 정의석: remaining=max(planned−(PLACED+HELD),0), FAILED 제외하여 재투입 가능.
- **공동 결정할 질문:** 예정 수량이 물리 박스 수인지 투입 회차 수인지 먼저 결정할 것. failed/held/passed/재투입의 완료·누적 처리·남은 수를 각각 정의하고 음성/HMI/DB 동일값으로 맞출 것.
- **남길 답변/증거:** failed→재투입→placed, passed→재투입→placed, held와 planned변경을 포함한 입력/예상 집계 표·음수 clamp·session 범위.
- **연결 ID:** SYS-FR-029·032, IC-STATS-01, TBD-007·008
- **작성·확인 책임:** 남현지 업무 의미, 정의석 SQL, 박병후 물리 분모 확인
- **같은 계약의 추가 확인 조합:** 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-022 — Stats 제공자·API와 메모리 백업

- **차이/현재 근거:** 남현지: DB기준 조회는 정의석 측 담당, manager Stats는 세션 메모리 백업 후보. 정의석: DB만 source of truth, provider 미정. query_kind/dong/session 요청·count/as_of 응답 제안.
- **공동 결정할 질문:** 서비스 이름 중복을 피하도록 단일 owner와 호출 경로를 정할 것. DB장애 시 메모리값을 공식 이력으로 내보낼지 금지/명시할지 결정. 기존 Stats는 빈 요청→total/placed/held/failed/json으로 새안과 다름.
- **남길 답변/증거:** Stats 최종 srv·owner·음성/HMI query 경로·DB unavailable 응답·commit snapshot/as_of 기준·동일 SQL.
- **연결 ID:** SYS-FR-029, IC-STATS-01, TBD-008·009
- **작성·확인 책임:** 정의석 조회안, 남현지 소비/현재 service 인계

### MC-023 — 전체 분류·이력 질의·HOLD·명령 인자

- **차이/현재 근거:** 남현지: 전체=priority(dong=""), 이력은 Stats 경로. V-05/FR018에는 start IDLE·PAUSED, 상세 전이표에는 start IDLE만/resume PAUSED. 정의석: priority는 dong필수, 전체=start(mode=all), query_history/query_kind 추가, 보류 zone=HOLD 후보. MQTT type/args.
- **공동 결정할 질문:** canonical command와 Command(command,arg) 직렬화 문법을 결정. 전체 전환과 시작/재개를 분리할지, query_history 라우터, HOLD↔hold↔보류, 동 allow-list/default값을 확인. 현지 회신 내부 start 불일치도 정정.
- **남길 답변/증거:** 운전/우선/전체/이력/답변 정답 JSON·Intent→service/MQTT 대응·상태별 유효표·접수/완료·command_id/TTL.
- **연결 ID:** SYS-FR-017·018·020·027·029, IC-CMD-01, TBD-005·009·011; CHG-EUS-01
- **작성·확인 책임:** 정의석 명령 schema, 남현지 FSM/서비스

### MC-024 — 질문 ID·답변 유효성·30초·TTS 실패

- **차이/현재 근거:** 남현지: question_id=box_id, 후보는 pending_question 문자열, say 발행 시각부터30초. 무효 답1회 재안내·timer유지·만료답무시. 정의석: 현재 Intent/say는 question_id가 없음, TTS 중 동시 입력 정책 미정. 박병후: 질문 시작/유효답/timeout 대기구간 측정 필요.
- **공동 결정할 질문:** 질문 ID를 명령에 실어야 할지, 늦은 답을 다음 질문에 적용하지 않는 상관 규약을 정할 것. 타이머 publication/재생시작/재생완료 기준과 TTS실패/stop/resume/API지연에서의 처리 및 human_wait 경계를 확인.
- **남길 답변/증거:** 질문/답 event schema·box/question 연결·무효/late/무응답/TTS실패 사례·30초 기준·측정 타임라인. 타이머 시작 차이는 미합의이며 상대가 다른 값을 확정한 것으로 쓰지 않음.
- **연결 ID:** SYS-FR-026·027·028, IC-VOICE-01·CMD-01·STATE-01, TBD-005·009·010·025
- **작성·확인 책임:** 남현지 질문 FSM, 정의석 음성, 박병후 시간 집계
- **같은 계약의 추가 확인 조합:** 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-025 — TTS 우선순위·중복 억제의 소유자

- **차이/현재 근거:** 남현지: 발화 우선순위/중복억제는 speech_out 결정. 정의석: 동일문구 중복은 upstream manager 책임 제안, speech_out dedupe 미정.
- **공동 결정할 질문:** 동일 box 이벤트 재전달과 서로 다른 box의 같은 문장을 구분할 것. stop/장비오류/질문/집계의 발화 우선순위·기존 발화 중단·dedupe key/window·half-duplex를 정할 것.
- **남길 답변/증거:** 발화 큐 정책·주담당·String 유지/메타데이터 필요성·반복/긴급발화 시험.
- **연결 ID:** SYS-FR-022, IC-VOICE-01, TBD-010
- **작성·확인 책임:** 정의석 speech_out, 남현지 발행 이벤트

### MC-026 — MQTT JSON·ack·중복·QoS·timestamp

- **차이/현재 근거:** 기존 mqtt.md: command/arg JSON. 정의석: command_id/type/args/sent_at JSON, ack topic 또는 HTTP 대안·QoS1 제안. 남현지: ROS Command는 command/arg, state reliable volatile 제안 vs conventions state transient_local. JSON변환 및 최종QoS 미확인.
- **공동 결정할 질문:** JSON→service 변환·ack경로·error/timeout·중복/TTL·retained 정책을 확정. 서로 다른 시계 ISO/epoch/ROS값 변환과 reconnect snapshot·broker 포트/도달성을 확인.
- **남길 답변/증거:** 4topic schema+command ack·QoS/retained표·중복미실행·재접속/연결상실 로그·port/NIC 조건. publish 성공과 manager 접수 구분.
- **연결 ID:** SYS-IF-006, IC-MQTT-01, TBD-011·026; CHG-EUS-01
- **작성·확인 책임:** 정의석 bridge/web, 남현지 ROS endpoint, 김학민 network
- **같은 계약의 추가 확인 조합:** 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md))

### MC-027 — DB 장애·다음 박스 허용·durable 보존

- **차이/현재 근거:** 남현지: manager는 저장 완료를 기다리지 않음. 정의석: commit 실패 집계 제외, 다음 박스 허용/queue/retry/보존/초기화는 미정. 박병후: A는 commit+query필수.
- **공동 결정할 질문:** 정상 운전 비차단과 DB 장애 정책을 별도 결정할 것. 영속 재전달·중복키·실패 알림/ack·buffer/backoff·유실 방지·next-box pause·세션/reset/보존 기간을 정할 것.
- **남길 답변/증거:** DB_ERROR event/표시·manager 상태·buffer한도/재기동 복원·writer/read 접속·volume/backup/retention/reset 표·장애 시험.
- **연결 ID:** SYS-DT-002·003, IC-DB-01, TBD-012·018
- **작성·확인 책임:** 정의석 저장 정책, 남현지 운전 상태, 박병후 G0 수락
- **같은 계약의 추가 확인 조합:** 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-028 — 공용 PC 사양·GPU 동거·음성/비전 선택

- **차이/현재 근거:** 정의석: MSI/i7/RAM32GB/4060Laptop8GB/드라이버595.91/CUDA13.2 등 문서상 #5 완료, 원본 로그 없음. 남현지: 사양은 회신 전달 내용, #5 미기록. 로컬 repo #5는 빈 칸. 음성/비전 동시 VRAM·CPU·주기 실측 없음.
- **공동 결정할 질문:** 기본 사양은 담당자 보고와 실측 증거를 구분할 것. #5 로그/측정일·실제컨테이너/driver/USB inventory를 보완하고 Whisper/YOLO/PaddleOCR 동시부하 조건을 정할 것.
- **남길 답변/증거:** env_report/nvidia-smi/USB/NIC 원본·실행 버전·동시 CPU/RAM/VRAM/latency/servo 로그·모델 선택 근거. Docker/CUDA 버전을 검증 완료로 쓰지 않음.
- **연결 ID:** SYS-CT-001·005, TBD-001·010·026
- **작성·확인 책임:** 정의석 PC/음성, 남현지 비전, 김학민 장비/NIC
- **같은 계약의 추가 확인 조합:** 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md))

### MC-029 — 호스트/컨테이너·DDS NIC·CT005 할당

- **차이/현재 근거:** 김학민: Mosquitto host1883, vision/DB owner 분리, DDS lo-only 수정 예정·유선 gateway 제거·host-network. 정의석: Web React+Spring Boot, DBPostgreSQL, broker host/container 모두 제안. 최종 위치/포트/볼륨 미정. 남현지 vision container.
- **공동 결정할 질문:** 실행 위치/이미지/포트/host-network/domain/NIC/읽기전용 설정/DBvolume를 정할 것. CT005 주담당 변경은 비전·DB 담당과 확인. DDS와 인터넷/MQTT 접근을 함께 검증.
- **남길 답변/증거:** 배포표·책임자·compose/launch 버전·포트/라우팅/DDS시험·API접속·기동/복구·volume. React/Spring/PostgreSQL은 현재 확정하지 않음.
- **연결 ID:** SYS-CT-005, VT-064, TBD-011·012·018·026; NEW-R-03
- **작성·확인 책임:** 김학민 network/host, 남현지 vision, 정의석 web/DB
- **같은 계약의 추가 확인 조합:** 김학민–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-033 — 선택 매핑/교시의 채택·원자 갱신

- **차이/현재 근거:** 남현지: 매핑변경10/11이후 채택 제안, 이미PICKING 목적구역 유지·원자swap/실패원복. 정의석/박병후: 후속검토, 현재선택미채택. 김학민: teach좌표 반환필드 없음/저장=manager원칙, TCP/플랜지차이.
- **공동 결정할 질문:** G0이후에만 채택 여부를 정할 것. 채택 시 동일box의 최종목적구역결정 시점·rule_version·confirm/rollback·teachpose반환/등록취소 경로를 확정.
- **남길 답변/증거:** 선택 채택/미채택 기록·영향·원자변경·TeachZone 응답·writer권한·별도시험. C미확정을A완료 차단조건으로 쓰지 않음.
- **연결 ID:** SYS-OP-001·002, IC-OPTION-01, TBD-023·024
- **작성·확인 책임:** 남현지 PL, 정의석 intent/HMI, 김학민 teach
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#18](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/18) · [#19](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/19) · [#20](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/20) · [#21](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/21) · [#22](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/22) · [#23](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/23) · [#29](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/29) · [#32](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/32)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.


---

# [SRD v0.2 상호확인] 김학민–박병후 — 계약·미정 12건 공동 회신

**작업:** create · **담당:** @rokeyhak, @ok778ts123

## 요청

**공동 확인:** 김학민 @rokeyhak · 박병후 @ok778ts123  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 12개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/06_김학민_박병후_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/06_김학민_박병후_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-002 / A — 고정 관측 자세 호모그래피와 이동 카메라 추종** (전제 충돌)
- [ ] **MC-004 / A/B — 촬영·pose·제어 시각과 시계 이력** (명시적 충돌·계약 공백)
- [ ] **MC-006 / A/B — 픽업 phase·성공 인계·reason enum** (명시적 충돌·상세 미정)
- [ ] **MC-008 / A/B — 10/10 게이트와 개루프 검토 조건** (회신↔기존 문서 충돌)
- [ ] **MC-009 / A — 단일 설정 snapshot·스키마·단위·유효값** (대체로 합치·상세 공백)
- [ ] **MC-010 / A — 플랜지/TCP·orientation·좌표 원점** (명시적 충돌·미정)
- [ ] **MC-011 / A/B — speedl/servol/move_line 실제 API·큐·주기** (후보 차이·실기 공백)
- [ ] **MC-012 / A — RG2 파지 성공 피드백과 판정 방법** (방향 합치·실측/타입 공백)
- [ ] **MC-013 / A — 닫힘 중 추종과 비차단 실행·busy 의미** (계약 공백)
- [ ] **MC-014 / A/B — cancel·watchdog·실제 정지 확인** (명시적 충돌·안전 계약 공백)
- [ ] **MC-016 / A/B — 적재 완료·결과 발행·복귀·DB 순서** (명시적 충돌·전달 경로 공백)
- [ ] **MC-031 / A/B — 시험 분모·판정·카드와 성능 측정 범위** (목표 합치·검증 상세 미정)

## 항목별 확인할 내용

### MC-002 — 고정 관측 자세 호모그래피와 이동 카메라 추종

- **차이/현재 근거:** 남현지: 현재 호모그래피는 observe_pose에서만 유효. 카메라 이동 시 정식 핸드아이로 보완 예정. 박병후: 손목 카메라가 움직이는 동안 촬영 시점 pose로 계속 base 위치를 산출하는 폐루프.
- **공동 결정할 질문:** 고정 자세 캘리브레이션만으로 이동 추종이 되는 것으로 가정하지 말 것. 핸드아이/촬영 시점 pose 이력/평면 교점 방식과 담당·완료 조건을 결정할 것.
- **남길 답변/증거:** observe_pose·카메라 내부/외부 파라미터·툴 기준·이동 중 변환 식/담당·정적/동적 검증 로그. ≤5mm는 승인 전 제안.
- **연결 ID:** SYS-FR-007·008, SYS-CT-002, TBD-002·014·020
- **작성·확인 책임:** 남현지 변환 설계, 김학민 기준 자세/실측, 박병후 소비 검증
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-004 — 촬영·pose·제어 시각과 시계 이력

- **차이/현재 근거:** 남현지: camera header.stamp를 호스트 촬영 시각으로 보존. 김학민: pose stamp는 조회 응답 수신 시각. 박병후: pose stamp는 실제 측정 시각, 촬영 시점의 pose/TF 이력 사용. 카메라 하드웨어 시계 매핑 확인 요구.
- **공동 결정할 질문:** 응답 수신 시각을 실제 장비 측정 시각으로 표기할 수 있는지 확인할 것. 불가하면 응답 시각·측정 불확실성·보간/예측 한계를 명시. 카메라 stamp domain, ROS/system/monotonic, 다중 PC 동기를 정할 것.
- **남길 답변/증거:** 시각 필드 정의표·시계 변환·pose 이력 보존/보간 범위·age/stale/future 기준·capture→consume 로그.
- **연결 ID:** SYS-PF-007, IC-VISION-01·02, IC-ROBOT-02, TBD-003·014·020·026
- **작성·확인 책임:** 김학민 pose 원천, 남현지 camera/변환, 박병후 제어 age
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-006 — 픽업 phase·성공 인계·reason enum

- **차이/현재 근거:** 남현지: approach/track/descend/grasp, 소문자 ok/lost/grasp_fail/canceled/robot_error. 박병후: prepare/track/descend/grasp/lift/verify, 대문자 OK/GRASP_FAILED/STALE_INPUT/DEVICE_ERROR 등 예시. 안전 높이까지 인계.
- **공동 결정할 질문:** phase와 reason의 최종 허용값·대소문자·ROS action status를 일치시킬 것. grasped=true의 물체 확보 및 lift 완료 경계와 인계 높이/자세를 명시할 것.
- **남길 답변/증거:** goal/feedback/result 정의·상태/사유 매핑표·인계 조건·timeout/BUSY 정책. err_u/v는 px 유지, m 오차는 별도 필드 후보.
- **연결 ID:** SYS-FR-009·010, SYS-IF-002, IC-PICK-01, TBD-019; NEW-B-04
- **작성·확인 책임:** 박병후 액션 의미, 남현지 소비, 김학민 모션 완료 확인
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md))

### MC-008 — 10/10 게이트와 개루프 검토 조건

- **차이/현재 근거:** 저장소 ADR-0002: B 개루프 베이스라인부터, 10/10 14/20 미달이면 B로 전환. 남현지: 같은 ADR을 기준으로 A/B 전환 가능 기재. 박병후: 폐루프 FF+P 우선. 실측 성능이 상당히 부족하다고 팀 판단할 때만 개루프 대안을 검토. 날짜/목표 미달로 자동 전환하지 않음.
- **공동 결정할 질문:** 현재 담당 방향과 팀 기준선을 동기화할 것. 70% 목표와 성능 점검은 유지하며 대안 검토 조건·결정자·증거·ADR 갱신을 확인.
- **남길 답변/증거:** 팀 검토 기록·ADR-0002 정정안·현재 채택 방식·전환 미결정/결정 여부. speedl 미지원과 폐루프 포기를 구분.
- **연결 ID:** TBD-021, SYS-FR-008, SYS-PF-001; NEW-B-05; ADR-0002
- **작성·확인 책임:** 박병후 방향 제시, 남현지 PL·김학민 실행 경로 확인
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md))

### MC-009 — 단일 설정 snapshot·스키마·단위·유효값

- **차이/현재 근거:** 남현지: 정적 값 launch→parameters, runtime writer=manager, belt direction_axis, 미정 null 제안. 김학민: 방향은 base 단위벡터, zones/limits 필요. 박병후: Kp/height/offset/age/watchdog/TCP/calibration/version/valid를 함께 검증.
- **공동 결정할 질문:** launch 전달 원칙을 수용하는지, 전체 schema와 소비자 목록·단위를 정할 것. 좌표 mm/deg와 제어 SI 변환, 부호 있는 벨트 단위벡터·속도, 0/null의 유효성을 필드별로 구분할 것.
- **남길 답변/증거:** 버전/해시 있는 초기 설정 예시·노드별 parameter 표·검증/READY 조건·누락 거부 사례. angular=0 같은 정상 0까지 일괄 금지하지 않음.
- **연결 ID:** SYS-FR-033, SYS-IF-007, IC-CONFIG-01, TBD-006·013·017·018·020
- **작성·확인 책임:** 남현지 schema/bringup, 김학민 실측/limits, 박병후 제어 값
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md))

### MC-010 — 플랜지/TCP·orientation·좌표 원점

- **차이/현재 근거:** 김학민: zones는 플랜지 기준(TCP 미적용), pose 기준점은 미정. 남현지: 캘리브레이션 TCP 터치. 박병후: 실제 TCP pose·파지 offset·상단 중심의 대응을 전제로 함.
- **공동 결정할 질문:** 장비 API가 반환하는 기준점과 설정/pose/캘리브레이션 기준점을 통일하거나 변환을 명시할 것. base_link가 실제 두산 베이스와 일치하는지, ZYZ↔quaternion과 각속도 의미도 확인.
- **남길 답변/증거:** TCP/tool 명칭·오프셋·frame 관계·단위·변환 예시·재기동 재등록 절차·측정 조건.
- **연결 ID:** SYS-FR-007·012, SYS-IF-003, IC-ROBOT-02·03, TBD-002·014·016
- **작성·확인 책임:** 김학민 장비 기준, 남현지 캘리브레이션, 박병후 파지 기준
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-011 — speedl/servol/move_line 실제 API·큐·주기

- **차이/현재 근거:** 김학민: 소스상 speedl_stream이 Twist와 의미 대응, M2.40 이상 조건·실장비 미확인. 서비스 단일 큐, stop 우회 후보. 박병후: latest base 속도 목표를 speedl 우선 실행, 옛 속도 목표 누적 금지. actual 적용과 publish를 구분 요구.
- **공동 결정할 질문:** 실제 설치 namespace/type/DRCF 지원·vel/acc/time/ref 단위·stream/서비스 동시성·pose 조회 경쟁을 확인할 것. 위치 명령으로 바꾸면 속도→목표 변환 의미를 별도 합의.
- **남길 답변/증거:** ros2 실제 타입/경로·설치 커밋·버전·유효명령/실제 적용 또는 관측 가능한 proxy 로그·주기/지터·고정자세 시험. 경로는 /dsr01/dsr_controller2/* 후보.
- **연결 ID:** SYS-CT-003, IC-ROBOT-01·DEVICE-01, TBD-014·020; NEW-B-02
- **작성·확인 책임:** 김학민 장비/API, 박병후 제어 출력

### MC-012 — RG2 파지 성공 피드백과 판정 방법

- **차이/현재 근거:** 김학민: Modbus grip_detected+busy+width 가용 후보, grip_detected AND 폭46±3mm 제안. 서비스 응답 필드 확장 제안. 박병후: 직접 물체 확보 피드백을 먼저 실험, 없다면 닫힘 완료+실측 폭+lift 유지. 판정 방법 유보.
- **공동 결정할 질문:** raw bit가 물체 확보를 의미하는지 빈 파지/정상/미끄러짐으로 검증할 것. width/힘/시간/valid/오류·최종 판정 방식을 선택하고 Gripper 응답을 결정.
- **남길 답변/증거:** 빈 파지·정상 파지 raw 로그/영상·stamp·busy 완료·폭 범위·최저 무손상 힘·최종 IDL/판정 표. 90mm/40mm/46±3mm는 실측 전 후보.
- **연결 ID:** SYS-FR-010, IC-ROBOT-03·DEVICE-01, TBD-015·019; NEW-R-02·NEW-B-03
- **작성·확인 책임:** 김학민 센서/경로, 박병후 성공 판정

### MC-013 — 닫힘 중 추종과 비차단 실행·busy 의미

- **차이/현재 근거:** 김학민: gripper 실제 완료 후 서비스 응답, 동시에 한 동작만/busy 거부, Modbus는 별도 연결. 박병후: async close 요청 중에도 추종을 계속하고, stop/watchdog은 우선 처리.
- **공동 결정할 질문:** 한 동작만이 로봇 모션과 RG2 병행까지 금지하는지 확인할 것. 콜백/큐 블로킹 없이 추종·pose·close·stop이 가능한지 실행 모델과 busy 기준을 결정.
- **남길 답변/증거:** 모션/그리퍼 소유 상태·허용 동시성 표·async 호출 시퀀스·timeout/중복 close/stop 시험.
- **연결 ID:** SYS-FR-009·010, IC-ROBOT-01·03, TBD-014·015·019
- **작성·확인 책임:** 김학민 gateway 실행 모델, 박병후 비차단 호출

### MC-014 — cancel·watchdog·실제 정지 확인

- **차이/현재 근거:** 남현지: cancel 후 servo가 0속도 발행 후 canceled 반환 제안. 김학민: stop 서비스·pose 변화 없음 확인, 감시시간 미정. 박병후: 단발 0속도 의존 금지, 실제 정지 확인 후 cancel 완료. pose만으로 actualstop 판단하지 않음. 불확실하면 STOP_UNCONFIRMED/PAUSED/새goal금지.
- **공동 결정할 질문:** 정지 요청 담당·우선순위·독립 watchdog·command expiry·실제 정지 확인 근거/연속 확인 조건을 정할 것. gateway 프로세스 종료 시 장비 동작도 시험하고 물체 보유 중 자동 개방 금지 여부를 결정.
- **남길 답변/증거:** 단계별 stop/cancel/노드 종료 시퀀스·/voss/robot/stop 최종 타입·정지 모드·timeout/최대 지연·거리·confirmed/unconfirmed 표시와 재개 조건.
- **연결 ID:** SYS-SF-001·002, IC-PICK-01·ROBOT-03, TBD-005·017·019·020; NEW-R-04
- **작성·확인 책임:** 김학민 실제 중단, 박병후 액션, 남현지 전체 PAUSED
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-016 — 적재 완료·결과 발행·복귀·DB 순서

- **차이/현재 근거:** 남현지: 최종 그리퍼 개방 성공 직후, 복귀 전 SortResult 발행, DB commit 기다리지 않음. 사이클 detected→result. 김학민: MoveToZone 내부에서 개방+observe 복귀까지 하고 응답. 박병후: 실제placed/observe_ready/db_committed를 분리, 정상 사이클detect→placed. 정의석: commit/조회가 A 완료 조건.
- **공동 결정할 질문:** 현재 서비스 응답만으로 복귀 전 개방/placed를 manager가 어떻게 아는지 결정할 것. 서비스 의미 변경/중간 이벤트/응답 시각 필드 등 대안을 비교. manager의 DB 비차단과 G0 검증의 commit 필수를 구분.
- **남길 답변/증거:** placed/result/observe_ready/db_committed/query 시퀀스·이벤트 생산자/타입/시각·실패 시 결과 규칙. 개방 ack만으로 올바른 물리 적재가 확인되는지도 명시.
- **연결 ID:** SYS-FR-012·013·014, SYS-PF-004, IC-ROBOT-03·RESULT-01·DB-01, TBD-007·012·016·025
- **작성·확인 책임:** 김학민 모션 이벤트, 남현지 result, 정의석 commit, 박병후 측정
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-031 — 시험 분모·판정·카드와 성능 측정 범위

- **차이/현재 근거:** 공통: 70%(20사례≥14)/OCR90·95/intent19of20/30초/3초/30Hz/100ms, 최종10물리박스≥8 목표. 전원실기 미수행. 정의석: API 실패는 intent 분모 별도, HMI 시작=bridge수신(전체 상태발행지연을 포함하지 않음). 반복횟수 제안 다수. 박병후: 사례사후제외금지, capture→consume 및 실제적용 구분.
- **공동 결정할 질문:** 실패/timeout/API오류/skip/재투입 분모·재시험 기준을 사전 고정할 것. HMI 상태 변경→DOM 목표와 bridge수신→DOM 부분구간을 구분하고 공용/브라우저 시계동기 방법을 정할 것. max/p95/평균 허용·부하·횟수/수행일을 승인.
- **남길 답변/증거:** 전체 VT계획표·case정답세트/환경·하위판정·수행일/확인자·rawlogs. 1차OCR≤300ms/검출30Hz BRD목표, 20ms·100ms crop 내부예산, ≤5mm제안 분리.
- **연결 ID:** SYS-PF-001~009, SYS-MT-001, TBD-020·022·025
- **작성·확인 책임:** 박병후 검증 취합, 각 기능 담당·남현지 PL
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 박병후–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md))

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#13](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/13) · [#34](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/34) · [#35](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/35) · [#36](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/36) · [#37](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/37) · [#39](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/39) · [#40](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/40) · [#41](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/41) · [#43](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/43) · [#44](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/44)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.


---

# [SRD v0.2 상호확인] 박병후–정의석 — 계약·미정 7건 공동 회신

**작업:** create · **담당:** @ok778ts123, @EuiseokJeongNZ

## 요청

**공동 확인:** 박병후 @ok778ts123 · 정의석 @EuiseokJeongNZ  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 7개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/07_박병후_정의석_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/07_박병후_정의석_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-003 / A/B — track/box/session/task/attempt 유일성과 재투입** (계약 공백·충돌 가능)
- [ ] **MC-016 / A/B — 적재 완료·결과 발행·복귀·DB 순서** (명시적 충돌·전달 경로 공백)
- [ ] **MC-021 / B — 남은 수에서 FAILED 포함·재투입 집계** (명시적 충돌)
- [ ] **MC-024 / B — 질문 ID·답변 유효성·30초·TTS 실패** (대체로 합치·계약 공백)
- [ ] **MC-027 / A/B — DB 장애·다음 박스 허용·durable 보존** (정책 미합의)
- [ ] **MC-030 / B — 정상 사이클의 감지/적재 경계·재시도 분류** (명시적 충돌·세부 공백)
- [ ] **MC-031 / A/B — 시험 분모·판정·카드와 성능 측정 범위** (목표 합치·검증 상세 미정)

## 항목별 확인할 내용

### MC-003 — track/box/session/task/attempt 유일성과 재투입

- **차이/현재 근거:** 남현지: 투입 회차별 box_id, 재시도는 같은 box_id의 attempt 1~3, 재투입은 새 box_id. 접두 MMDDTHHMM-순번. 정의석: attempt_id 또는 처리 시도별 box_id 유일키 제안. 박병후: task/session/attempt와 물리 박스 대응 필요.
- **공동 결정할 질문:** 처리 시도라는 말이 투입 회차인지 파지 재시도인지 통일할 것. 같은 분 재시작·노드 재기동·해가 바뀌어도 DB 키 충돌이 없는지, track 만료 후 같은 박스와 재투입을 구분하는지 확인할 것.
- **남길 답변/증거:** ID 대응표·유일키·생성/만료 주체·재시작 규약·물리 박스 시험대장. retry/reinsert/중복 수신 각 예시와 DB 행 수.
- **연결 ID:** SYS-FR-004·014, SYS-DT-001, TBD-003·007·008·012·022
- **작성·확인 책임:** 남현지 업무 ID, 정의석 DB키, 박병후 시험 ID 취합
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md)), 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md))

### MC-016 — 적재 완료·결과 발행·복귀·DB 순서

- **차이/현재 근거:** 남현지: 최종 그리퍼 개방 성공 직후, 복귀 전 SortResult 발행, DB commit 기다리지 않음. 사이클 detected→result. 김학민: MoveToZone 내부에서 개방+observe 복귀까지 하고 응답. 박병후: 실제placed/observe_ready/db_committed를 분리, 정상 사이클detect→placed. 정의석: commit/조회가 A 완료 조건.
- **공동 결정할 질문:** 현재 서비스 응답만으로 복귀 전 개방/placed를 manager가 어떻게 아는지 결정할 것. 서비스 의미 변경/중간 이벤트/응답 시각 필드 등 대안을 비교. manager의 DB 비차단과 G0 검증의 commit 필수를 구분.
- **남길 답변/증거:** placed/result/observe_ready/db_committed/query 시퀀스·이벤트 생산자/타입/시각·실패 시 결과 규칙. 개방 ack만으로 올바른 물리 적재가 확인되는지도 명시.
- **연결 ID:** SYS-FR-012·013·014, SYS-PF-004, IC-ROBOT-03·RESULT-01·DB-01, TBD-007·012·016·025
- **작성·확인 책임:** 김학민 모션 이벤트, 남현지 result, 정의석 commit, 박병후 측정
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-021 — 남은 수에서 FAILED 포함·재투입 집계

- **차이/현재 근거:** 남현지: remaining=planned−(placed+held+failed), passed 제외. 정의석: remaining=max(planned−(PLACED+HELD),0), FAILED 제외하여 재투입 가능.
- **공동 결정할 질문:** 예정 수량이 물리 박스 수인지 투입 회차 수인지 먼저 결정할 것. failed/held/passed/재투입의 완료·누적 처리·남은 수를 각각 정의하고 음성/HMI/DB 동일값으로 맞출 것.
- **남길 답변/증거:** failed→재투입→placed, passed→재투입→placed, held와 planned변경을 포함한 입력/예상 집계 표·음수 clamp·session 범위.
- **연결 ID:** SYS-FR-029·032, IC-STATS-01, TBD-007·008
- **작성·확인 책임:** 남현지 업무 의미, 정의석 SQL, 박병후 물리 분모 확인
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-024 — 질문 ID·답변 유효성·30초·TTS 실패

- **차이/현재 근거:** 남현지: question_id=box_id, 후보는 pending_question 문자열, say 발행 시각부터30초. 무효 답1회 재안내·timer유지·만료답무시. 정의석: 현재 Intent/say는 question_id가 없음, TTS 중 동시 입력 정책 미정. 박병후: 질문 시작/유효답/timeout 대기구간 측정 필요.
- **공동 결정할 질문:** 질문 ID를 명령에 실어야 할지, 늦은 답을 다음 질문에 적용하지 않는 상관 규약을 정할 것. 타이머 publication/재생시작/재생완료 기준과 TTS실패/stop/resume/API지연에서의 처리 및 human_wait 경계를 확인.
- **남길 답변/증거:** 질문/답 event schema·box/question 연결·무효/late/무응답/TTS실패 사례·30초 기준·측정 타임라인. 타이머 시작 차이는 미합의이며 상대가 다른 값을 확정한 것으로 쓰지 않음.
- **연결 ID:** SYS-FR-026·027·028, IC-VOICE-01·CMD-01·STATE-01, TBD-005·009·010·025
- **작성·확인 책임:** 남현지 질문 FSM, 정의석 음성, 박병후 시간 집계
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-027 — DB 장애·다음 박스 허용·durable 보존

- **차이/현재 근거:** 남현지: manager는 저장 완료를 기다리지 않음. 정의석: commit 실패 집계 제외, 다음 박스 허용/queue/retry/보존/초기화는 미정. 박병후: A는 commit+query필수.
- **공동 결정할 질문:** 정상 운전 비차단과 DB 장애 정책을 별도 결정할 것. 영속 재전달·중복키·실패 알림/ack·buffer/backoff·유실 방지·next-box pause·세션/reset/보존 기간을 정할 것.
- **남길 답변/증거:** DB_ERROR event/표시·manager 상태·buffer한도/재기동 복원·writer/read 접속·volume/backup/retention/reset 표·장애 시험.
- **연결 ID:** SYS-DT-002·003, IC-DB-01, TBD-012·018
- **작성·확인 책임:** 정의석 저장 정책, 남현지 운전 상태, 박병후 G0 수락
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-030 — 정상 사이클의 감지/적재 경계·재시도 분류

- **차이/현재 근거:** 남현지: detected→SortResult(placed, decided_by=ocr), 재시도 포함 여부 명시 없음. 박병후: t_detect→실제t_placed, result/return/commit 별도. retry도 예외로 제안. 정상/예외/작업자대기 분리는 공통.
- **공동 결정할 질문:** t_detect는 최초 유효 capture/검출 처리/수신 중 무엇인지, placed는 물리 완료의 어떤 이벤트인지 결정. retry 포함/제외와 최대값/분포 합격 기준·종료실패/skip 측정을 확정.
- **남길 답변/증거:** 이벤트명·생산자·공통ID·clock·정상/예외 분류표·측정 계산식·CSV예시. human wait 구간은 MC024와 동일 결정.
- **연결 ID:** SYS-PF-004, VT-048, TBD-025
- **작성·확인 책임:** 박병후 측정, 남현지 detect/result, 김학민 placed, 정의석 evidence
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md))

### MC-031 — 시험 분모·판정·카드와 성능 측정 범위

- **차이/현재 근거:** 공통: 70%(20사례≥14)/OCR90·95/intent19of20/30초/3초/30Hz/100ms, 최종10물리박스≥8 목표. 전원실기 미수행. 정의석: API 실패는 intent 분모 별도, HMI 시작=bridge수신(전체 상태발행지연을 포함하지 않음). 반복횟수 제안 다수. 박병후: 사례사후제외금지, capture→consume 및 실제적용 구분.
- **공동 결정할 질문:** 실패/timeout/API오류/skip/재투입 분모·재시험 기준을 사전 고정할 것. HMI 상태 변경→DOM 목표와 bridge수신→DOM 부분구간을 구분하고 공용/브라우저 시계동기 방법을 정할 것. max/p95/평균 허용·부하·횟수/수행일을 승인.
- **남길 답변/증거:** 전체 VT계획표·case정답세트/환경·하위판정·수행일/확인자·rawlogs. 1차OCR≤300ms/검출30Hz BRD목표, 20ms·100ms crop 내부예산, ≤5mm제안 분리.
- **연결 ID:** SYS-PF-001~009, SYS-MT-001, TBD-020·022·025
- **작성·확인 책임:** 박병후 검증 취합, 각 기능 담당·남현지 PL
- **같은 계약의 추가 확인 조합:** 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 김학민–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md))

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#13](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/13) · [#18](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/18) · [#19](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/19) · [#20](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/20) · [#21](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/21) · [#22](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/22) · [#23](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/23) · [#37](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/37)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.


---

# [SRD v0.2 상호확인] 김학민–정의석 — 계약·미정 4건 공동 회신

**작업:** create · **담당:** @rokeyhak, @EuiseokJeongNZ

## 요청

**공동 확인:** 김학민 @rokeyhak · 정의석 @EuiseokJeongNZ  
**취합:** 박병후 @ok778ts123 · **PL:** 남현지 @yujh5537  
**상위 관리:** [#6 SRD·시스템 아키텍처 반영](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/6)

두 사람의 회신을 대조해 아래 4개 항목에서 답변 차이 또는 계약·실측·승인 근거가 부족한 부분을 찾았습니다. **A 최소 연결을 먼저 확인해 이 이슈에 공동 회신**해 주세요. 각자 SRD를 따로 수정할 필요는 없습니다. ‘제안/목표/실측 대기’는 확정·통과로 바꾸지 않습니다.

## 일정·범위

| 일정(KST) | 마감·목표 |
| --- | --- |
| 상호확인 공동 회신 | **2026-10-06 18:30까지** |
| 첫 실기 실험·실측 | **2026-10-07까지** |
| G0 실제 1박스 전체 흐름 통과 | **2026-10-10까지** |

G0는 실제 박스 한 개의 인식→이동 중 픽업→올바른 기본 구역 적재→DB commit·조회→복귀/다음 관측 준비가 모두 확인돼야 통과합니다. 구체 장비 시간·검토 방식·확인자는 별도 협의합니다.

**단계:** A는 최초 전체 흐름 필수, B는 최종 시연 필수(음성·HMI·예외·이력·재시도·성능·컨테이너), C는 G0 이후 채택하는 선택 범위(규칙 변경·신규 구역 교시)입니다.

## 이 이슈의 문서

- [이 조합 상호확인서 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/08_김학민_정의석_상호확인.md)
- [이 조합 상호확인서 — Word](repository_files/docs/requirements/srd-v0.2-r2/word/08_김학민_정의석_상호확인.docx)
- [SRD v0.2 r2 — Markdown](repository_files/docs/requirements/srd-v0.2-r2/markdown/01_VOSS_SRD_v0.2_r2_회신취합반영본.md) / [Word](repository_files/docs/requirements/srd-v0.2-r2/word/01_VOSS_SRD_v0.2_r2_회신취합반영본.docx)
- [합치·충돌·미정 통합대장](repository_files/docs/requirements/srd-v0.2-r2/markdown/02_합치_충돌_미정_통합대장.md)
- [70개 요구사항/검증 카드 매핑](repository_files/docs/requirements/srd-v0.2-r2/markdown/09_검증카드_70개요구사항_매핑.md)
- [전체 자료 ZIP — Word·Markdown·원본·그림 포함](repository_files/docs/requirements/srd-v0.2-r2/VOSS_SRD_v0.2_r2_회신취합_상호확인.zip)

## 확인 목록

아래 체크는 **이 조합의 답변과 두 사람 확인을 받았는지** 표시합니다. 다른 조합까지 연결된 MC-ID의 전체 계약 확정은 상위 #6에서 취합합니다.

- [ ] **MC-019 / A/B — 준비 판단 주담당·상태 원천·기동** (할당 변경 제안·전달 공백)
- [ ] **MC-026 / B — MQTT JSON·ack·중복·QoS·timestamp** (회신↔기존 계약 차이·미정)
- [ ] **MC-028 / A/B — 공용 PC 사양·GPU 동거·음성/비전 선택** (증거 수준 차이·자원 공백)
- [ ] **MC-029 / A/B — 호스트/컨테이너·DDS NIC·CT005 할당** (상세 미정·담당 변경 제안)

## 항목별 확인할 내용

### MC-019 — 준비 판단 주담당·상태 원천·기동

- **차이/현재 근거:** 김학민: FR-001 주담당은 manager 남현지로 변경, gateway는 READY/로봇 상태 제공. stop/observe/state 신설 제안. 박병후: 설정/유효 입력/gateway READY 필수. 정의석: HMI 로봇 상태 데이터 원천 없음. 남현지: 통합 상태는6개 후보.
- **공동 결정할 질문:** FR-001의 주담당 변경·각 파트 ready/error/heartbeat와 통합 판단·로봇 상태 필드를 확인할 것. 관측 자세 이동 요청(zone=observe 또는 별도)을 정하고 launch/툴 등록/설정 적용 순서를 정할 것.
- **남길 답변/증거:** ready matrix·발행 주체/타입/주기·미준비 차단·stale/UNKNOWN 표시·기동/복구 체크. 상태 신설과 FR 담당 변경은 승인 후 반영.
- **연결 ID:** SYS-FR-001·031, IC-STATE-01, TBD-011·018; NEW-R-01·05·06
- **작성·확인 책임:** 남현지 통합, 김학민 장비, 정의석 화면/저장, 박병후 servo
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–박병후([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-026 — MQTT JSON·ack·중복·QoS·timestamp

- **차이/현재 근거:** 기존 mqtt.md: command/arg JSON. 정의석: command_id/type/args/sent_at JSON, ack topic 또는 HTTP 대안·QoS1 제안. 남현지: ROS Command는 command/arg, state reliable volatile 제안 vs conventions state transient_local. JSON변환 및 최종QoS 미확인.
- **공동 결정할 질문:** JSON→service 변환·ack경로·error/timeout·중복/TTL·retained 정책을 확정. 서로 다른 시계 ISO/epoch/ROS값 변환과 reconnect snapshot·broker 포트/도달성을 확인.
- **남길 답변/증거:** 4topic schema+command ack·QoS/retained표·중복미실행·재접속/연결상실 로그·port/NIC 조건. publish 성공과 manager 접수 구분.
- **연결 ID:** SYS-IF-006, IC-MQTT-01, TBD-011·026; CHG-EUS-01
- **작성·확인 책임:** 정의석 bridge/web, 남현지 ROS endpoint, 김학민 network
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-028 — 공용 PC 사양·GPU 동거·음성/비전 선택

- **차이/현재 근거:** 정의석: MSI/i7/RAM32GB/4060Laptop8GB/드라이버595.91/CUDA13.2 등 문서상 #5 완료, 원본 로그 없음. 남현지: 사양은 회신 전달 내용, #5 미기록. 로컬 repo #5는 빈 칸. 음성/비전 동시 VRAM·CPU·주기 실측 없음.
- **공동 결정할 질문:** 기본 사양은 담당자 보고와 실측 증거를 구분할 것. #5 로그/측정일·실제컨테이너/driver/USB inventory를 보완하고 Whisper/YOLO/PaddleOCR 동시부하 조건을 정할 것.
- **남길 답변/증거:** env_report/nvidia-smi/USB/NIC 원본·실행 버전·동시 CPU/RAM/VRAM/latency/servo 로그·모델 선택 근거. Docker/CUDA 버전을 검증 완료로 쓰지 않음.
- **연결 ID:** SYS-CT-001·005, TBD-001·010·026
- **작성·확인 책임:** 정의석 PC/음성, 남현지 비전, 김학민 장비/NIC
- **같은 계약의 추가 확인 조합:** 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-029 — 호스트/컨테이너·DDS NIC·CT005 할당

- **차이/현재 근거:** 김학민: Mosquitto host1883, vision/DB owner 분리, DDS lo-only 수정 예정·유선 gateway 제거·host-network. 정의석: Web React+Spring Boot, DBPostgreSQL, broker host/container 모두 제안. 최종 위치/포트/볼륨 미정. 남현지 vision container.
- **공동 결정할 질문:** 실행 위치/이미지/포트/host-network/domain/NIC/읽기전용 설정/DBvolume를 정할 것. CT005 주담당 변경은 비전·DB 담당과 확인. DDS와 인터넷/MQTT 접근을 함께 검증.
- **남길 답변/증거:** 배포표·책임자·compose/launch 버전·포트/라우팅/DDS시험·API접속·기동/복구·volume. React/Spring/PostgreSQL은 현재 확정하지 않음.
- **연결 ID:** SYS-CT-005, VT-064, TBD-011·012·018·026; NEW-R-03
- **작성·확인 책임:** 김학민 network/host, 남현지 vision, 정의석 web/DB
- **같은 계약의 추가 확인 조합:** 남현지–김학민([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md)), 남현지–정의석([이슈 초안](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md))

### MC-ID별 공동 회신 형식

주 작성자가 아래 형식으로 댓글을 남기고 상대가 같은 MC-ID와 최종 답변에 확인 댓글을 남깁니다. 여러 항목을 한 댓글에 묶어도 MC-ID는 각각 유지합니다. Word/Markdown 양식을 채웠다면 이 이슈 댓글에 파일과 증거를 첨부해도 됩니다.

```text
MC-ID:
판정: 합의 / 일부 합의 / 불일치 유지 / 실측 대기 / 해당 없음(이유)
최종 규약: 이름·타입·필드·값·단위·좌표·시각·QoS·완료/오류 중 해당 사항
A 최소 연결 답변 / B 후속 답변 / C 채택 상태:
변경 제안: 기존 SYS/IC/VT/카드 ID, 변경 전→후, 필수 이유, 영향받는 파트/계약/시험
실제 데이터 예시·시퀀스:
검증: 모의/실기, 목표/설정/실측, 조건·횟수·증거 경로/commit/PR
남은 미정: 이유·담당·KST 예정일·영향 단계
두 사람 확인: 이름·확인 일시
추가로 확인할 조합/MC-ID:
```

요구사항·ID·인터페이스/검증 카드의 수정·추가·삭제는 반드시 해결할 문제에 한해 신중히 제안합니다. 기존 행과 ID는 지우거나 재사용하지 않고 수정/삭제 제안으로 표시합니다. ID 변경은 이전→새 ID 대응을, 추가 항목은 담당별 임시 ID를 남깁니다. 관련 담당자 확인·PL 검토 후 병후가 확정 SRD에 반영합니다.

## 회신·상태 관리

- [ ] 모든 해당 MC-ID에 공동 답변 또는 미정 이유·담당·예정일을 남겼다.
- [ ] 두 사람의 확인 이름·일시와 실제 데이터 예시/증거를 남겼다.
- [ ] A 최소와 B 후속, C 채택 상태를 나눴다.
- [ ] 다자 계약의 추가 확인과 후속 구현/실기 작업은 연결된 MC-ID·기존 작업 이슈에 기록했다.

이 조합의 회신을 받으면 병후가 체크를 갱신합니다. 해당 조합의 확인 작업을 종료해도 다자 계약의 전체 승인·실측·G0/G2 수락 상태는 상위 #6에 따로 남깁니다. 해결되지 않은 필수 계약은 담당/기한/후속 이슈를 명시해 계속 추적합니다. 정상 자동 사이클과 예외 처리를 나누고 작업자 대기는 별도 기록합니다.

## 기존 작업과 연결

[#10](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/10) · [#20](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/20) · [#21](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/21) · [#22](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/22) · [#31](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/31) · [#40](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/40) · [#41](https://github.com/yujh5537/rokey_cobot2_VOSS/issues/41)

이 이슈는 계약 상호확인과 공동 회신을 관리합니다. 합의 뒤 구현·실측·검증 결과는 기존 작업 이슈와 PR에 연결합니다.

