# VOSS SRD v0.2 — GitHub 이슈 배포 초안

**상태: 초안 작성 완료 / GitHub 파일 게시·PR·이슈 변경·신규 등록 미수행**  
**저장소:** [yujh5537/rokey_cobot2_VOSS](https://github.com/yujh5537/rokey_cobot2_VOSS)  
**기준일:** 2026-10-06 KST

기존 **#6을 상위 관리로 보강하는 초안1개 + 공동 확인용 신규 이슈6개**를 작성했다. 기존 #6의 본문과 미완료 체크를 그대로 보존하고 새 취합 관리 내용을 뒤에 추가했다. 작업 이슈 #10~46을 중복 생성하지 않고 관련 링크로 연결했다.

## 일정

- 공동 회신: **오늘10/06 18:30 KST까지**
- 첫 실기 실험·실측: **10/07까지**
- 실제1박스 전체 흐름 G0 통과: **10/10까지**

## 초안 파일

| 작업 | 본문/미리보기 | 담당 |
| --- | --- | --- |
| #6본문보강 | [00_기존이슈6_본문보강초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/00_기존이슈6_본문보강초안.md) | @ok778ts123 |
| 신규이슈 | [01_남현지_박병후_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/01_남현지_박병후_신규이슈초안.md) | @yujh5537, @ok778ts123 |
| 신규이슈 | [02_남현지_김학민_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/02_남현지_김학민_신규이슈초안.md) | @yujh5537, @rokeyhak |
| 신규이슈 | [03_남현지_정의석_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/03_남현지_정의석_신규이슈초안.md) | @yujh5537, @EuiseokJeongNZ |
| 신규이슈 | [04_김학민_박병후_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/04_김학민_박병후_신규이슈초안.md) | @rokeyhak, @ok778ts123 |
| 신규이슈 | [05_박병후_정의석_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/05_박병후_정의석_신규이슈초안.md) | @ok778ts123, @EuiseokJeongNZ |
| 신규이슈 | [06_김학민_정의석_신규이슈초안.md](repository_files/docs/requirements/srd-v0.2-r2/issue_drafts/06_김학민_정의석_신규이슈초안.md) | @rokeyhak, @EuiseokJeongNZ |

각 조합 초안은 담당 계정·일정·모든 MC-ID 체크리스트·양쪽 답변 차이·확인 질문·필요 증거·공동 댓글 양식·변경 규약·기존 작업 이슈·문서 첨부 링크를 포함한다.

## 첨부 자료

SRD r2,통합대장,6개 확인서,배포안내,70개 검증카드 매핑,추가자료/실행순서의 Word·Markdown 11개씩,시스템 그림,원본 회신4개,이전SRD/결정대장,manifest/검증정보와 전체ZIP을 같은 자료 폴더에 준비했다.

초안 Markdown 링크는 로컬/저장소 파일 미리보기에서 열리는 상대 경로다. **GitHub 이슈 본문에 게시할 때는 `issue_payloads.json`의 `body_github_template`에 실제 문서 게시 commit SHA를 채워 절대링크로 변환한다.** 아직 생성하지 않은 브랜치/commit/이슈 번호를 게시된 링크로 표시하지 않았다. 실제 등록 후 상위 #6에는 자식 이슈 번호·상태를, 자식 이슈에는 다른 조합의 실제 이슈 링크를 연결한다.

## 실제 게시 단계

1. 공개 저장소에 게시할 첨부 범위를 승인받는다. 자동 승인 검토가 원문 포함 전체 자료의 공개 업로드를 거절해 현재 모든 외부 쓰기는 중단했다.
2. 승인 범위의 문서만 전용 브랜치에 올리고 실제 commit SHA를 확보한다. 원문 제외를 선택하면 ZIP/링크/manifest에서도 원문을 제외한다.
3. 템플릿 링크를 실제 commit SHA에 고정하고 문서 Draft PR을 열어 검토한다. `main`에 직접 푸시하지 않는다.
4. 최종 이슈 본문을 확인해 조합별6개를등록하고 기존#6에관리블록을추가한다. 기존본문/체크/댓글은보존한다.
5. 상위/자식이슈번호·첨부링크·담당·라벨을검증한다. 같은MC-ID의양쪽확인과전체계약상태는별도로관리한다.

원문/문서 공개 승인을 받기 전에는 GitHub API 업로드를 재시도하지 않는다. 초안/첨부는 로컬 파일과 다운로드 ZIP으로 제공한다.
